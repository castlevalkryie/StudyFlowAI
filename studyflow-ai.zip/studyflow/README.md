# StudyFlow AI 🎓⚡

An AI-powered study planning platform with spaced repetition, gamification, smart scheduling, and an AI coach.

## Features

- **Smart Study Planner** — Auto-schedules study sessions based on due dates, difficulty, and confidence
- **Spaced Repetition** — SM-2 algorithm reviews (1 → 3 → 7 → 14 → 30 days)
- **AI Coach** — Conversational study coach with personalized advice
- **Gamification** — XP, levels (Rookie → Master), streaks, achievement badges  
- **Analytics** — Charts for hours studied, completion rate, subject breakdown
- **Calendar** — Day/week/month views with drag-to-reschedule
- **Dark/Light mode** — Full theme support

## Tech Stack

- **Frontend**: React 18 + TypeScript + Tailwind CSS + Vite + Recharts
- **Backend**: Node.js + Express + SQLite (better-sqlite3)
- **Auth**: JWT (30-day tokens)
- **State**: Zustand (persisted)

## Quick Start

### Prerequisites
- Node.js 18+
- npm 9+

### 1. Install dependencies

```bash
# Root (concurrently)
npm install

# Server
cd server && npm install

# Client
cd ../client && npm install
```

### 2. Set up environment

```bash
cd server
# .env is already configured for development
# Edit JWT_SECRET in production!
```

### 3. Seed demo data

```bash
cd server
node db/seed.js
# Creates demo@studyflow.ai / demo1234
```

### 4. Start development servers

```bash
# From root:
npm run dev

# Or separately:
# Terminal 1: cd server && npm run dev
# Terminal 2: cd client && npm run dev
```

- Frontend: http://localhost:5173
- API: http://localhost:3001

## Demo Login

```
Email: demo@studyflow.ai
Password: demo1234
```

## Project Structure

```
studyflow/
├── server/
│   ├── db/
│   │   ├── database.js      # SQLite schema + init
│   │   └── seed.js          # Demo data
│   ├── middleware/
│   │   └── auth.js          # JWT middleware
│   ├── routes/              # Express route handlers
│   ├── services/
│   │   ├── scheduler.js     # Study schedule algorithm
│   │   ├── spacedRepetition.js  # SM-2 algorithm
│   │   ├── gamification.js  # XP + level system
│   │   └── coach.js         # AI coach (rule-based, LLM-ready)
│   └── index.js             # Express app
└── client/
    └── src/
        ├── pages/           # Route components
        ├── components/      # Shared UI
        ├── lib/             # API client, stores, utils
        └── types/           # TypeScript types
```

## API Reference

| Method | Path | Description |
|--------|------|-------------|
| POST | /api/auth/register | Create account |
| POST | /api/auth/login | Get JWT token |
| GET | /api/auth/me | Current user + stats |
| GET | /api/assignments | List assignments |
| POST | /api/assignments | Create assignment (auto-schedules) |
| PATCH | /api/assignments/:id | Update/complete |
| GET | /api/schedule/today | Today's sessions |
| POST | /api/schedule/generate | Regenerate full schedule |
| PATCH | /api/schedule/:id/complete | Mark session done (+XP) |
| GET | /api/reviews/due | Reviews due today |
| POST | /api/reviews/:id/complete | Rate review (SM-2) |
| GET | /api/analytics/overview | Full analytics data |
| GET | /api/gamification/status | XP, level, badges |
| POST | /api/coach/message | Chat with AI coach |

## Adding Real AI to the Coach

Replace the `generateCoachResponse` function in `server/services/coach.js`:

```js
const OpenAI = require('openai');
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function generateCoachResponse(message, context, history) {
  const completion = await client.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [
      { role: 'system', content: `You are StudyFlow Coach, a supportive AI study tutor. Student context: ${JSON.stringify(context)}` },
      ...history,
      { role: 'user', content: message }
    ]
  });
  return completion.choices[0].message.content;
}
```

## Future Expansions (Architecture Ready)

- **AI Quiz Generation** — `/api/ai/quiz` endpoint skeleton in place
- **AI Flashcards** — extend review_items with card_front/card_back fields
- **Note Summarization** — add notes field to assignments + AI summary endpoint
- **Essay Feedback** — POST /api/ai/feedback with submission text
- **Push Notifications** — notification table schema included

## Production Deployment

```bash
# Build frontend
cd client && npm run build

# Serve with Express (add to server/index.js):
app.use(express.static('../client/dist'))
app.get('*', (_, res) => res.sendFile(path.join(__dirname, '../client/dist/index.html')))
```

Set these env vars in production:
- `JWT_SECRET` — long random string
- `NODE_ENV=production`
- `DB_PATH` — persistent volume path
