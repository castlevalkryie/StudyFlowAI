import { Outlet, Navigate } from 'react-router-dom';
import { Zap } from 'lucide-react';
import { useAuthStore } from '../../lib/api';

export default function AuthLayout() {
  const { user } = useAuthStore();
  if (user) return <Navigate to="/dashboard" replace />;
  return (
    <div className="min-h-screen bg-[#0f0f13] flex items-center justify-center p-4">
      <div className="w-full max-w-md animate-slide-up">
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-2xl bg-brand-500 flex items-center justify-center mx-auto mb-4">
            <Zap className="w-6 h-6 text-white" />
          </div>
          <h1 className="font-display text-2xl font-bold">StudyFlow <span className="text-brand-400">AI</span></h1>
          <p className="text-[#8b8b9e] text-sm mt-1">Your AI-powered study coach</p>
        </div>
        <div className="card p-8">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
