import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, BookOpen, Calendar, Bot, BarChart2, RefreshCw, Settings, LogOut, Zap, Flame, Star, Menu, X } from 'lucide-react';
import { useState, useEffect } from 'react';
import { useAuthStore, useThemeStore } from '../../lib/api';
import { cn, getInitials, getLevelColor, formatXP } from '../../lib/utils';
import api from '../../lib/api';
import type { GamificationStatus } from '../../types';
import toast from 'react-hot-toast';

const NAV = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/assignments', icon: BookOpen, label: 'Assignments' },
  { to: '/calendar', icon: Calendar, label: 'Calendar' },
  { to: '/reviews', icon: RefreshCw, label: 'Reviews' },
  { to: '/coach', icon: Bot, label: 'AI Coach' },
  { to: '/analytics', icon: BarChart2, label: 'Analytics' },
];

export default function AppLayout() {
  const { user, logout } = useAuthStore();
  const { theme, toggleTheme } = useThemeStore();
  const navigate = useNavigate();
  const [gamification, setGamification] = useState<GamificationStatus | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    api.get('/gamification/status').then(r => setGamification(r.data)).catch(() => {});
  }, []);

  const handleLogout = () => {
    logout();
    toast.success('Logged out');
    navigate('/login');
  };

  const levelColor = getLevelColor(gamification?.level_info?.level || 1);
  const xp = gamification?.xp || 0;
  const xpPct = gamification?.progress_pct || 0;

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="px-4 py-5">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-brand-500 flex items-center justify-center">
            <Zap className="w-4 h-4 text-white" />
          </div>
          <span className="font-display text-lg font-bold">StudyFlow <span className="text-brand-400">AI</span></span>
        </div>
      </div>

      {/* XP / Level card */}
      {gamification && (
        <div className="mx-3 mb-4 p-3 rounded-xl bg-[#22222f] border border-[#2e2e3e]">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5">
              <Star className="w-3.5 h-3.5" style={{ color: levelColor }} />
              <span className="text-xs font-semibold" style={{ color: levelColor }}>
                Lv.{gamification.level_info.level} {gamification.level_info.name}
              </span>
            </div>
            <div className="flex items-center gap-1 text-xs text-[#8b8b9e]">
              <Flame className="w-3.5 h-3.5 text-orange-400" />
              <span className="font-semibold text-orange-400">{gamification.stats?.streak_current || 0}</span>
            </div>
          </div>
          <div className="xp-bar">
            <div className="xp-fill" style={{ width: `${xpPct}%` }} />
          </div>
          <div className="flex justify-between mt-1">
            <span className="text-[10px] text-[#8b8b9e]">{formatXP(xp)} XP</span>
            <span className="text-[10px] text-[#8b8b9e]">{formatXP(xp + (gamification.xp_to_next || 0))} XP</span>
          </div>
        </div>
      )}

      {/* Nav */}
      <nav className="flex-1 px-2 space-y-0.5">
        {NAV.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            onClick={() => setSidebarOpen(false)}
            className={({ isActive }) => cn('nav-item', isActive ? 'nav-item-active' : 'nav-item-inactive')}
          >
            <Icon className="w-4 h-4 flex-shrink-0" />
            {label}
          </NavLink>
        ))}
      </nav>

      {/* Footer */}
      <div className="p-3 border-t border-[#2e2e3e] space-y-1">
        <NavLink to="/settings" onClick={() => setSidebarOpen(false)} className={({ isActive }) => cn('nav-item', isActive ? 'nav-item-active' : 'nav-item-inactive')}>
          <Settings className="w-4 h-4" />
          Settings
        </NavLink>
        <button onClick={handleLogout} className="nav-item nav-item-inactive w-full text-left text-red-400 hover:text-red-400 hover:bg-red-500/10">
          <LogOut className="w-4 h-4" />
          Log out
        </button>
        {user && (
          <div className="flex items-center gap-3 px-3 pt-2 mt-1 border-t border-[#2e2e3e]">
            <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold text-white flex-shrink-0"
              style={{ background: user.avatar_color }}>
              {getInitials(user.name)}
            </div>
            <div className="min-w-0">
              <p className="text-sm font-medium truncate">{user.name}</p>
              <p className="text-xs text-[#8b8b9e] truncate">{user.email}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Desktop sidebar */}
      <aside className="hidden md:flex w-60 flex-col bg-[#1a1a24] border-r border-[#2e2e3e] flex-shrink-0">
        <SidebarContent />
      </aside>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
          <aside className="relative z-10 w-64 h-full bg-[#1a1a24] border-r border-[#2e2e3e]">
            <button onClick={() => setSidebarOpen(false)} className="absolute top-4 right-4 text-[#8b8b9e] hover:text-white">
              <X className="w-5 h-5" />
            </button>
            <SidebarContent />
          </aside>
        </div>
      )}

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile topbar */}
        <div className="md:hidden flex items-center gap-3 px-4 py-3 bg-[#1a1a24] border-b border-[#2e2e3e]">
          <button onClick={() => setSidebarOpen(true)} className="text-[#8b8b9e]">
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-brand-400" />
            <span className="font-display font-bold text-sm">StudyFlow AI</span>
          </div>
        </div>

        <main className="flex-1 overflow-y-auto bg-[#0f0f13]">
          <div className="max-w-7xl mx-auto p-4 md:p-6 animate-fade-in">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
