import { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, RefreshCw, Check, X } from 'lucide-react';
import api from '../lib/api';
import { cn, SUBJECT_ICONS, formatSessionTime } from '../lib/utils';
import type { StudySession } from '../types';
import { format, startOfWeek, endOfWeek, addDays, addWeeks, subWeeks, parseISO, isSameDay, startOfMonth, endOfMonth, addMonths, subMonths, eachDayOfInterval, isSameMonth } from 'date-fns';
import toast from 'react-hot-toast';

type View = 'day' | 'week' | 'month';

export default function Calendar() {
  const [view, setView] = useState<View>('week');
  const [current, setCurrent] = useState(new Date());
  const [sessions, setSessions] = useState<StudySession[]>([]);
  const [generating, setGenerating] = useState(false);

  useEffect(() => { loadSessions(); }, [current, view]);

  const loadSessions = async () => {
    let start: string, end: string;
    if (view === 'day') { start = format(current, 'yyyy-MM-dd'); end = format(current, 'yyyy-MM-dd'); }
    else if (view === 'week') { start = format(startOfWeek(current, { weekStartsOn: 1 }), 'yyyy-MM-dd'); end = format(endOfWeek(current, { weekStartsOn: 1 }), 'yyyy-MM-dd'); }
    else { start = format(startOfMonth(current), 'yyyy-MM-dd'); end = format(endOfMonth(current), 'yyyy-MM-dd'); }
    const r = await api.get(`/schedule?start=${start}&end=${end}`);
    setSessions(r.data);
  };

  const generate = async () => {
    setGenerating(true);
    try {
      const r = await api.post('/schedule/generate');
      toast.success(`Generated ${r.data.generated} study sessions`);
      loadSessions();
    } catch { toast.error('Failed to generate'); } finally { setGenerating(false); }
  };

  const completeSession = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const r = await api.patch(`/schedule/${id}/complete`);
    toast.success(`+${r.data.xp_awarded} XP!`);
    loadSessions();
  };

  const missSession = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    await api.patch(`/schedule/${id}/miss`);
    toast('Session marked missed', { icon: '😔' });
    loadSessions();
  };

  const nav = (dir: 1 | -1) => {
    if (view === 'day') setCurrent(addDays(current, dir));
    else if (view === 'week') setCurrent(dir > 0 ? addWeeks(current, 1) : subWeeks(current, 1));
    else setCurrent(dir > 0 ? addMonths(current, 1) : subMonths(current, 1));
  };

  const SessionChip = ({ s }: { s: StudySession }) => (
    <div className={cn('text-xs rounded-lg p-1.5 border mb-1 flex items-center gap-1.5 group',
      s.status === 'completed' ? 'opacity-50 border-green-500/20 bg-green-500/5' :
      s.status === 'missed' ? 'opacity-50 border-red-500/20 bg-red-500/5' :
      'border-[#2e2e3e] hover:border-brand-500/30 cursor-pointer')}
      style={{ borderLeftColor: s.subject_color || '#6366f1', borderLeftWidth: 3 }}>
      <span className="flex-1 truncate font-medium">{s.title}</span>
      <span className="text-[9px] text-[#8b8b9e] flex-shrink-0">{s.duration_minutes}m</span>
      {s.status === 'scheduled' && (
        <div className="hidden group-hover:flex gap-1">
          <button onClick={e => completeSession(s.id, e)} className="text-green-400 hover:text-green-300"><Check className="w-3 h-3" /></button>
          <button onClick={e => missSession(s.id, e)} className="text-red-400 hover:text-red-300"><X className="w-3 h-3" /></button>
        </div>
      )}
    </div>
  );

  const headerLabel = view === 'day' ? format(current, 'EEEE, MMMM d, yyyy')
    : view === 'week' ? `${format(startOfWeek(current, { weekStartsOn: 1 }), 'MMM d')} – ${format(endOfWeek(current, { weekStartsOn: 1 }), 'MMM d, yyyy')}`
    : format(current, 'MMMM yyyy');

  // Week view days
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(startOfWeek(current, { weekStartsOn: 1 }), i));
  // Month view
  const monthDays = eachDayOfInterval({ start: startOfWeek(startOfMonth(current), { weekStartsOn: 1 }), end: endOfWeek(endOfMonth(current), { weekStartsOn: 1 }) });

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3 justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold">Calendar</h1>
          <p className="text-[#8b8b9e] text-sm mt-0.5">{sessions.length} sessions in view</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={generate} disabled={generating}
            className="btn-primary flex items-center gap-2 text-sm py-2">
            <RefreshCw className={cn('w-4 h-4', generating && 'animate-spin')} />
            {generating ? 'Generating...' : 'Auto-schedule'}
          </button>
        </div>
      </div>

      <div className="card p-4">
        {/* Controls */}
        <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
          <div className="flex items-center gap-2">
            <button onClick={() => nav(-1)} className="p-2 rounded-xl hover:bg-[#22222f] transition-all"><ChevronLeft className="w-4 h-4" /></button>
            <button onClick={() => setCurrent(new Date())} className="text-sm px-3 py-1.5 rounded-xl hover:bg-[#22222f] font-medium">Today</button>
            <button onClick={() => nav(1)} className="p-2 rounded-xl hover:bg-[#22222f] transition-all"><ChevronRight className="w-4 h-4" /></button>
            <span className="font-semibold text-sm ml-1">{headerLabel}</span>
          </div>
          <div className="flex rounded-xl bg-[#22222f] p-1 gap-1">
            {(['day', 'week', 'month'] as View[]).map(v => (
              <button key={v} onClick={() => setView(v)}
                className={cn('px-3 py-1.5 rounded-lg text-sm font-medium capitalize transition-all',
                  view === v ? 'bg-brand-500 text-white' : 'text-[#8b8b9e] hover:text-white')}>
                {v}
              </button>
            ))}
          </div>
        </div>

        {/* Day view */}
        {view === 'day' && (
          <div className="space-y-2">
            {sessions.filter(s => isSameDay(parseISO(s.scheduled_start), current)).length === 0
              ? <div className="text-center py-10 text-[#8b8b9e]">No sessions on this day</div>
              : sessions.filter(s => isSameDay(parseISO(s.scheduled_start), current)).map(s => (
                <div key={s.id} className={cn('flex gap-4 p-3 rounded-xl border', s.status === 'completed' ? 'border-green-500/20 bg-green-500/5 opacity-60' : 'border-[#2e2e3e] hover:border-brand-500/30')}>
                  <div className="text-xs text-[#8b8b9e] w-28 flex-shrink-0 pt-0.5">{formatSessionTime(s.scheduled_start, s.scheduled_end)}</div>
                  <div className="flex-1">
                    <p className="font-medium text-sm">{s.title}</p>
                    <p className="text-xs text-[#8b8b9e]">{s.duration_minutes} min {s.subject_name && `· ${s.subject_name}`}</p>
                  </div>
                  {s.status === 'scheduled' && (
                    <div className="flex gap-2">
                      <button onClick={e => completeSession(s.id, e)} className="btn-primary text-xs py-1.5 px-3">Done</button>
                    </div>
                  )}
                  {s.status === 'completed' && <span className="text-green-400 text-xs">✓ +{s.xp_awarded} XP</span>}
                </div>
              ))
            }
          </div>
        )}

        {/* Week view */}
        {view === 'week' && (
          <div className="grid grid-cols-7 gap-1 min-w-0">
            {weekDays.map(day => (
              <div key={day.toISOString()}>
                <div className={cn('text-center py-2 mb-1 rounded-lg',
                  isSameDay(day, new Date()) ? 'bg-brand-500 text-white' : 'text-[#8b8b9e]')}>
                  <p className="text-[10px] uppercase font-semibold">{format(day, 'EEE')}</p>
                  <p className="text-sm font-bold">{format(day, 'd')}</p>
                </div>
                <div className="min-h-[200px]">
                  {sessions.filter(s => isSameDay(parseISO(s.scheduled_start), day)).map(s => (
                    <SessionChip key={s.id} s={s} />
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Month view */}
        {view === 'month' && (
          <div>
            <div className="grid grid-cols-7 mb-2">
              {['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(d => (
                <div key={d} className="text-center text-xs font-semibold text-[#8b8b9e] py-2">{d}</div>
              ))}
            </div>
            <div className="grid grid-cols-7 gap-px bg-[#2e2e3e]">
              {monthDays.map(day => {
                const daySessions = sessions.filter(s => isSameDay(parseISO(s.scheduled_start), day));
                return (
                  <div key={day.toISOString()}
                    className={cn('bg-[#1a1a24] min-h-[80px] p-1.5',
                      !isSameMonth(day, current) && 'opacity-30',
                      isSameDay(day, new Date()) && 'bg-brand-500/5')}>
                    <p className={cn('text-xs font-semibold mb-1 w-5 h-5 flex items-center justify-center rounded-full',
                      isSameDay(day, new Date()) ? 'bg-brand-500 text-white' : 'text-[#8b8b9e]')}>
                      {format(day, 'd')}
                    </p>
                    {daySessions.slice(0, 3).map(s => <SessionChip key={s.id} s={s} />)}
                    {daySessions.length > 3 && <p className="text-[10px] text-[#8b8b9e]">+{daySessions.length - 3} more</p>}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
