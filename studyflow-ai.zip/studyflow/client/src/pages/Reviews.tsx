import { useEffect, useState } from 'react';
import { Brain, CheckCircle, Clock, Calendar } from 'lucide-react';
import api from '../lib/api';
import type { ReviewItem } from '../types';
import { cn } from '../lib/utils';
import { format, parseISO } from 'date-fns';
import toast from 'react-hot-toast';

export default function Reviews() {
  const [dueReviews, setDueReviews] = useState<ReviewItem[]>([]);
  const [allReviews, setAllReviews] = useState<ReviewItem[]>([]);
  const [current, setCurrent] = useState<ReviewItem | null>(null);
  const [showAnswer, setShowAnswer] = useState(false);
  const [mode, setMode] = useState<'queue' | 'list'>('queue');

  useEffect(() => { loadAll(); }, []);

  const loadAll = async () => {
    const [due, all] = await Promise.all([api.get('/reviews/due'), api.get('/reviews')]);
    setDueReviews(due.data);
    setAllReviews(all.data);
    if (due.data.length > 0 && !current) setCurrent(due.data[0]);
  };

  const rate = async (quality: number) => {
    if (!current) return;
    await api.post(`/reviews/${current.id}/complete`, { quality });
    const remaining = dueReviews.filter(r => r.id !== current.id);
    setDueReviews(remaining);
    setShowAnswer(false);
    setCurrent(remaining[0] || null);
    toast.success(quality >= 4 ? '+25 XP — great recall! 🧠' : quality >= 3 ? '+25 XP — reviewed!' : 'Noted — will review sooner');
    loadAll();
  };

  const qualityButtons = [
    { q: 0, label: "Forgot", desc: "Complete blackout", color: 'border-red-500/30 text-red-400 hover:bg-red-500/10' },
    { q: 2, label: "Hard", desc: "Recalled with difficulty", color: 'border-orange-500/30 text-orange-400 hover:bg-orange-500/10' },
    { q: 3, label: "Okay", desc: "Recalled with effort", color: 'border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10' },
    { q: 4, label: "Good", desc: "Recalled easily", color: 'border-green-500/30 text-green-400 hover:bg-green-500/10' },
    { q: 5, label: "Perfect", desc: "Instant recall", color: 'border-brand-500/30 text-brand-400 hover:bg-brand-500/10' },
  ];

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold flex items-center gap-2">
            <Brain className="w-6 h-6 text-brand-400" />
            Spaced Reviews
          </h1>
          <p className="text-[#8b8b9e] text-sm mt-0.5">
            {dueReviews.length} due today · {allReviews.length} total topics
          </p>
        </div>
        <div className="flex gap-2">
          {(['queue', 'list'] as const).map(m => (
            <button key={m} onClick={() => setMode(m)}
              className={cn('px-3 py-1.5 rounded-xl text-sm font-medium capitalize transition-all',
                mode === m ? 'bg-brand-500 text-white' : 'border border-[#2e2e3e] text-[#8b8b9e] hover:border-brand-500/30')}>
              {m === 'queue' ? `Review (${dueReviews.length})` : 'All topics'}
            </button>
          ))}
        </div>
      </div>

      {/* Review queue mode */}
      {mode === 'queue' && (
        <>
          {dueReviews.length === 0 ? (
            <div className="card p-10 text-center animate-fade-in">
              <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-3" />
              <h2 className="font-display text-xl font-bold mb-2">All caught up! 🎉</h2>
              <p className="text-[#8b8b9e]">No reviews due right now. Come back later or browse all topics.</p>
            </div>
          ) : current ? (
            <div className="max-w-xl mx-auto space-y-4">
              {/* Progress */}
              <div className="flex items-center gap-3">
                <div className="flex-1 h-2 bg-[#22222f] rounded-full overflow-hidden">
                  <div className="h-full bg-brand-500 rounded-full transition-all"
                    style={{ width: `${((allReviews.length - dueReviews.length) / allReviews.length) * 100}%` }} />
                </div>
                <span className="text-xs text-[#8b8b9e]">{dueReviews.length} remaining</span>
              </div>

              {/* Card */}
              <div className="card p-8 text-center min-h-[280px] flex flex-col items-center justify-center gap-6 animate-slide-up">
                <div className="flex items-center gap-2">
                  {current.subject_color && <div className="w-3 h-3 rounded-full" style={{ background: current.subject_color }} />}
                  <span className="text-xs text-[#8b8b9e]">{current.subject_name || 'General'}</span>
                  <span className="text-xs text-[#8b8b9e]">· Review #{current.review_count + 1}</span>
                </div>

                <div>
                  <p className="text-xs text-[#8b8b9e] uppercase tracking-widest mb-3">Topic to recall</p>
                  <h2 className="font-display text-2xl font-bold">{current.topic}</h2>
                </div>

                {!showAnswer ? (
                  <div className="space-y-3">
                    <p className="text-sm text-[#8b8b9e]">Close your eyes and recall everything you know about this topic, then rate yourself.</p>
                    <button onClick={() => setShowAnswer(true)} className="btn-primary px-8 py-3">
                      I've thought about it →
                    </button>
                  </div>
                ) : (
                  <div className="w-full space-y-3 animate-slide-up">
                    <p className="text-sm text-[#8b8b9e] font-medium">How well did you recall this?</p>
                    <div className="grid grid-cols-5 gap-2">
                      {qualityButtons.map(b => (
                        <button key={b.q} onClick={() => rate(b.q)}
                          className={cn('flex flex-col items-center gap-1 p-2 rounded-xl border text-xs font-medium transition-all', b.color)}>
                          <span className="font-bold">{b.label}</span>
                          <span className="text-[9px] opacity-70 hidden sm:block">{b.desc}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : null}
        </>
      )}

      {/* List mode */}
      {mode === 'list' && (
        <div className="space-y-2">
          {allReviews.map(r => (
            <div key={r.id} className="card p-4 flex items-center gap-3">
              <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ background: r.subject_color || '#6366f1' }} />
              <div className="flex-1">
                <p className="font-medium text-sm">{r.topic}</p>
                <p className="text-xs text-[#8b8b9e]">{r.subject_name || 'General'} · {r.review_count} reviews</p>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-1 text-xs text-[#8b8b9e]">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Next: {format(parseISO(r.next_review_date), 'MMM d')}</span>
                </div>
                <div className="flex items-center gap-1 text-xs text-[#8b8b9e] mt-0.5">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Interval: {r.interval_days}d</span>
                </div>
              </div>
            </div>
          ))}
          {allReviews.length === 0 && <div className="card p-8 text-center text-[#8b8b9e]">No review topics yet. Add tests or quizzes to automatically create reviews.</div>}
        </div>
      )}

      {/* Info panel */}
      <div className="card p-5 border-brand-500/10 bg-brand-500/5">
        <h3 className="font-semibold text-sm flex items-center gap-2 mb-2">
          <Brain className="w-4 h-4 text-brand-400" />
          How spaced repetition works
        </h3>
        <p className="text-xs text-[#8b8b9e] leading-relaxed">
          Topics are reviewed at increasing intervals: <strong className="text-[#f1f1f5]">1 → 3 → 7 → 14 → 30 days</strong>. 
          Each time you rate a topic well, the interval grows. If you struggle, it resets.
          This exploits the spacing effect — one of the most proven memory techniques in cognitive science.
        </p>
      </div>
    </div>
  );
}
