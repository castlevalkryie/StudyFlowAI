import { useEffect, useState } from 'react';
import { Moon, Sun, User, Clock, BookOpen } from 'lucide-react';
import api, { useAuthStore, useThemeStore } from '../lib/api';
import toast from 'react-hot-toast';

const COLORS = ['#6366f1','#10b981','#f59e0b','#ec4899','#14b8a6','#8b5cf6','#ef4444','#3b82f6'];

export default function Settings() {
  const { user, updateUser } = useAuthStore();
  const { theme, toggleTheme } = useThemeStore();
  const [form, setForm] = useState({ name: user?.name || '', daily_study_hours: user?.daily_study_hours || 2, preferred_session_length: user?.preferred_session_length || 25, avatar_color: user?.avatar_color || '#6366f1' });
  const [saving, setSaving] = useState(false);
  const [subjects, setSubjects] = useState<any[]>([]);
  const [newSubject, setNewSubject] = useState({ name: '', color: '#6366f1', icon: 'book' });

  useEffect(() => { api.get('/subjects').then(r => setSubjects(r.data)); }, []);

  const saveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.patch('/auth/me', form);
      updateUser(form);
      toast.success('Settings saved');
    } catch { toast.error('Failed to save'); } finally { setSaving(false); }
  };

  const addSubject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubject.name) return;
    const r = await api.post('/subjects', newSubject);
    setSubjects(prev => [...prev, r.data]);
    setNewSubject({ name: '', color: '#6366f1', icon: 'book' });
    toast.success('Subject added');
  };

  const deleteSubject = async (id: string) => {
    await api.delete(`/subjects/${id}`);
    setSubjects(prev => prev.filter(s => s.id !== id));
    toast.success('Deleted');
  };

  return (
    <div className="space-y-6 max-w-2xl animate-fade-in">
      <h1 className="font-display text-2xl font-bold">Settings</h1>

      {/* Profile */}
      <div className="card p-6 space-y-4">
        <h2 className="font-semibold flex items-center gap-2"><User className="w-4 h-4 text-brand-400" /> Profile</h2>
        <form onSubmit={saveProfile} className="space-y-4">
          <div>
            <label className="label">Name</label>
            <input className="input" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
          </div>
          <div>
            <label className="label">Avatar color</label>
            <div className="flex gap-2 mt-1">
              {COLORS.map(c => (
                <button key={c} type="button" onClick={() => setForm(f => ({ ...f, avatar_color: c }))}
                  className={`w-8 h-8 rounded-full transition-all ${form.avatar_color === c ? 'ring-2 ring-white ring-offset-2 ring-offset-[#1a1a24] scale-110' : ''}`}
                  style={{ background: c }} />
              ))}
            </div>
          </div>
          <button type="submit" className="btn-primary" disabled={saving}>{saving ? 'Saving...' : 'Save profile'}</button>
        </form>
      </div>

      {/* Study preferences */}
      <div className="card p-6 space-y-4">
        <h2 className="font-semibold flex items-center gap-2"><Clock className="w-4 h-4 text-brand-400" /> Study preferences</h2>
        <form onSubmit={saveProfile} className="space-y-4">
          <div>
            <label className="label">Daily study goal: <span className="text-brand-400">{form.daily_study_hours}h</span></label>
            <input type="range" min={0.5} max={8} step={0.5} value={form.daily_study_hours}
              onChange={e => setForm(f => ({ ...f, daily_study_hours: +e.target.value }))}
              className="w-full h-2 bg-[#22222f] rounded-full appearance-none cursor-pointer accent-brand-500" />
            <div className="flex justify-between text-[10px] text-[#8b8b9e]"><span>30min</span><span>8h</span></div>
          </div>
          <div>
            <label className="label">Session length: <span className="text-brand-400">{form.preferred_session_length}min</span></label>
            <input type="range" min={15} max={90} step={5} value={form.preferred_session_length}
              onChange={e => setForm(f => ({ ...f, preferred_session_length: +e.target.value }))}
              className="w-full h-2 bg-[#22222f] rounded-full appearance-none cursor-pointer accent-brand-500" />
            <div className="flex justify-between text-[10px] text-[#8b8b9e]"><span>15min</span><span>90min</span></div>
          </div>
          <button type="submit" className="btn-primary" disabled={saving}>Save preferences</button>
        </form>
      </div>

      {/* Theme */}
      <div className="card p-6">
        <h2 className="font-semibold mb-4">Appearance</h2>
        <button onClick={toggleTheme} className="flex items-center gap-3 p-3 rounded-xl border border-[#2e2e3e] hover:border-brand-500/30 transition-all w-full">
          {theme === 'dark' ? <Moon className="w-5 h-5 text-brand-400" /> : <Sun className="w-5 h-5 text-yellow-400" />}
          <div className="text-left">
            <p className="font-medium text-sm">{theme === 'dark' ? 'Dark mode' : 'Light mode'}</p>
            <p className="text-xs text-[#8b8b9e]">Click to switch</p>
          </div>
        </button>
      </div>

      {/* Subjects */}
      <div className="card p-6 space-y-4">
        <h2 className="font-semibold flex items-center gap-2"><BookOpen className="w-4 h-4 text-brand-400" /> Subjects</h2>
        <div className="space-y-2">
          {subjects.map(s => (
            <div key={s.id} className="flex items-center gap-3 p-2 rounded-xl hover:bg-[#22222f]">
              <div className="w-6 h-6 rounded-full flex-shrink-0" style={{ background: s.color }} />
              <span className="flex-1 text-sm">{s.name}</span>
              <button onClick={() => deleteSubject(s.id)} className="text-[#8b8b9e] hover:text-red-400 text-xs">Remove</button>
            </div>
          ))}
        </div>
        <form onSubmit={addSubject} className="flex gap-2">
          <input className="input flex-1" placeholder="New subject..." value={newSubject.name}
            onChange={e => setNewSubject(n => ({ ...n, name: e.target.value }))} />
          <input type="color" value={newSubject.color} onChange={e => setNewSubject(n => ({ ...n, color: e.target.value }))}
            className="w-10 h-10 rounded-xl cursor-pointer bg-transparent border border-[#2e2e3e]" />
          <button type="submit" className="btn-primary px-4">Add</button>
        </form>
      </div>
    </div>
  );
}
