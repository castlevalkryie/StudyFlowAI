import { useEffect, useRef, useState } from 'react';
import { Send, Trash2, Bot, User, Zap, Sparkles } from 'lucide-react';
import api from '../lib/api';
import { cn } from '../lib/utils';
import type { CoachMessage } from '../types';
import { format, parseISO } from 'date-fns';
import toast from 'react-hot-toast';

const QUICK_PROMPTS = [
  "What should I study next?",
  "Give me a study strategy",
  "I'm struggling with my workload",
  "How does spaced repetition work?",
  "Help me prepare for my test",
  "I need motivation",
];

function renderMarkdown(text: string) {
  return text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/\n/g, '<br/>');
}

export default function Coach() {
  const [messages, setMessages] = useState<CoachMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingHistory, setLoadingHistory] = useState(true);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    api.get('/coach/history').then(r => {
      setMessages(r.data);
      setLoadingHistory(false);
    }).catch(() => setLoadingHistory(false));
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const send = async (msg?: string) => {
    const text = (msg || input).trim();
    if (!text || loading) return;
    setInput('');
    setMessages(prev => [...prev, { id: Date.now().toString(), role: 'user', content: text, created_at: new Date().toISOString() }]);
    setLoading(true);
    try {
      const r = await api.post('/coach/message', { message: text });
      setMessages(prev => [...prev, { id: Date.now().toString() + 'r', role: 'assistant', content: r.data.response, created_at: new Date().toISOString() }]);
    } catch { toast.error('Coach is unavailable'); setLoading(false); }
    setLoading(false);
  };

  const clearHistory = async () => {
    if (!confirm('Clear conversation history?')) return;
    await api.delete('/coach/history');
    setMessages([]);
    toast.success('History cleared');
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] max-h-[800px]">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-brand-500/20 border border-brand-500/30 flex items-center justify-center">
            <Bot className="w-5 h-5 text-brand-400" />
          </div>
          <div>
            <h1 className="font-display text-xl font-bold flex items-center gap-2">
              StudyFlow Coach
              <span className="flex items-center gap-1 text-[10px] bg-green-500/10 text-green-400 border border-green-500/20 px-2 py-0.5 rounded-full font-normal">
                <span className="w-1.5 h-1.5 bg-green-400 rounded-full" />
                Online
              </span>
            </h1>
            <p className="text-[#8b8b9e] text-xs">Your personalized AI study coach</p>
          </div>
        </div>
        {messages.length > 0 && (
          <button onClick={clearHistory} className="btn-ghost text-sm flex items-center gap-1.5 text-[#8b8b9e]">
            <Trash2 className="w-3.5 h-3.5" /> Clear
          </button>
        )}
      </div>

      {/* Chat area */}
      <div className="card flex-1 flex flex-col overflow-hidden">
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Welcome screen */}
          {messages.length === 0 && !loadingHistory && (
            <div className="flex flex-col items-center justify-center h-full gap-4 animate-fade-in">
              <div className="w-16 h-16 rounded-3xl bg-brand-500/20 border border-brand-500/30 flex items-center justify-center">
                <Sparkles className="w-8 h-8 text-brand-400" />
              </div>
              <div className="text-center">
                <h2 className="font-display text-lg font-bold">Meet your Coach</h2>
                <p className="text-[#8b8b9e] text-sm mt-1 max-w-sm">I can help you study smarter, suggest what to review next, and keep you motivated.</p>
              </div>
              <div className="grid grid-cols-2 gap-2 w-full max-w-md">
                {QUICK_PROMPTS.map(p => (
                  <button key={p} onClick={() => send(p)}
                    className="text-left text-xs p-3 rounded-xl border border-[#2e2e3e] hover:border-brand-500/30 hover:bg-brand-500/5 transition-all text-[#8b8b9e] hover:text-[#f1f1f5]">
                    {p}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Messages */}
          {messages.map(msg => (
            <div key={msg.id} className={cn('flex gap-3 animate-slide-up', msg.role === 'user' ? 'flex-row-reverse' : 'flex-row')}>
              <div className={cn('w-7 h-7 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5',
                msg.role === 'user' ? 'bg-brand-500' : 'bg-brand-500/20 border border-brand-500/30')}>
                {msg.role === 'user' ? <User className="w-3.5 h-3.5 text-white" /> : <Bot className="w-3.5 h-3.5 text-brand-400" />}
              </div>
              <div className={cn('max-w-[80%] rounded-2xl px-4 py-3',
                msg.role === 'user' ? 'bg-brand-500 rounded-tr-sm' : 'bg-[#22222f] border border-[#2e2e3e] rounded-tl-sm')}>
                <div className={cn('text-sm leading-relaxed', msg.role === 'user' ? 'text-white' : 'text-[#f1f1f5]')}
                  dangerouslySetInnerHTML={{ __html: renderMarkdown(msg.content) }} />
                <p className={cn('text-[10px] mt-1.5', msg.role === 'user' ? 'text-white/60 text-right' : 'text-[#8b8b9e]')}>
                  {format(parseISO(msg.created_at), 'h:mm a')}
                </p>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex gap-3 animate-fade-in">
              <div className="w-7 h-7 rounded-xl bg-brand-500/20 border border-brand-500/30 flex items-center justify-center flex-shrink-0">
                <Bot className="w-3.5 h-3.5 text-brand-400" />
              </div>
              <div className="bg-[#22222f] border border-[#2e2e3e] rounded-2xl rounded-tl-sm px-4 py-3">
                <div className="flex gap-1">
                  {[0,1,2].map(i => (
                    <div key={i} className="w-2 h-2 bg-brand-500 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
                  ))}
                </div>
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div className="border-t border-[#2e2e3e] p-4">
          {messages.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-3">
              {QUICK_PROMPTS.slice(0, 3).map(p => (
                <button key={p} onClick={() => send(p)}
                  className="text-xs px-3 py-1.5 rounded-xl bg-[#22222f] border border-[#2e2e3e] text-[#8b8b9e] hover:border-brand-500/30 hover:text-brand-400 transition-all">
                  {p}
                </button>
              ))}
            </div>
          )}
          <div className="flex gap-3">
            <input className="input flex-1" placeholder="Ask your coach anything..."
              value={input} onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()} />
            <button onClick={() => send()} disabled={!input.trim() || loading}
              className="btn-primary px-4 flex-shrink-0 flex items-center gap-2">
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
