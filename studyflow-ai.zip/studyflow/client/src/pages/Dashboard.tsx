import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Flame, Trophy, Clock, CheckCircle, AlertCircle, ArrowRight, Zap, Brain, RefreshCw } from 'lucide-react';
import api, { useAuthStore } from '../lib/api';
import { cn, formatDueDate, PRIORITY_CONFIG, TYPE_CONFIG, SUBJECT_ICONS, formatXP, getLevelColor } from '../lib/utils';
import type { StudySession, Assignment, ReviewItem, GamificationStatus } from '../types';
import { format, parseISO } from 'date-fns';
import toast from 'react-hot-toast';

export default function Dashboard() {
  const { user } = useAuthStore();
  const [sessions, setSessions] = useState<StudySession[]>([]);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [reviews, setReviews] = useState<ReviewItem[]>([]);
  const [gamification, setGamification] = useState<GamificationStatus | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [s, a, r, g] = await Promise.all([
          api.get('/schedule/today'),
          api.get('/assignments?status=pending'),
          api.get('/reviews/due'),
          api.get('/gamification/status'),
        ]);
        setSessions(s.data);
        setAssignments(a.data.slice(0, 5));
        setReviews(r.data.slice(0, 3));
        setGamification(g.data);
      } finally { setLoading(false); }
    };
    load();
  }, []);

  const completeSession = async (id: string) => {
    try {
      const r = await api.patch(`/schedule/${id}/complete`);
      setSessions(prev => prev.map(s => s.id === id ? { ...s, status: 'completed' } : s));
      toast.success(`+${r.data.xp_awarded} XP earned! 🎉`);
      const g = await api.get('/gamification/status');
      setGamification(g.data);
    } catch { toast.error('Failed to complete session'); }
  };

  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
  const name = user?.name?.split(' ')[0] || 'there';
  const streak = gamification?.stats?.streak_current || 0;
  const xp = gamification?.xp || 0;
  const level = gamification?.level_info;
  const xpPct = gamification?.progress_pct || 0;
  const levelColor = getLevelColor(level?.level || 1);

  if (loading) return <div className="flex items-center justify-center h-64"><div className="w-6 h-6 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Hero greeting */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl md:text-3xl font-bold">{greeting}, {name}! 👋</h1>
          <p className="text-[#8b8b9e] mt-1">
            {sessions.filter(s => s.status === 'scheduled').length} sessions planned today
            {reviews.length > 0 && ` · ${reviews.length} reviews due`}
          </p>
        </div>
        {streak > 0 && (
          <div className="flex items-center gap-2 bg-orange-500/10 border border-orange-500/20 rounded-2xl px-4 py-2.5">
            <Flame className="w-5 h-5 text-orange-400" />
            <div>
              <p className="text-sm font-bold text-orange-400">{streak} day streak</p>
              <p className="text-[10px] text-[#8b8b9e]">Keep it up!</p>
            </div>
          </div>
        )}
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* XP / Level */}
        <div className="card p-4 col-span-2 lg:col-span-1">
          <div className="flex items-center gap-2 mb-2">
            <Trophy className="w-4 h-4" style={{ color: levelColor }} />
            <span className="text-xs font-semibold" style={{ color: levelColor }}>Level {level?.level}</span>
          </div>
          <p className="font-display text-xl font-bold">{formatXP(xp)} XP</p>
          <p className="text-xs text-[#8b8b9e] mt-0.5">{level?.name}</p>
          <div className="xp-bar mt-2">
            <div className="xp-fill" style={{ width: `${xpPct}%` }} />
          </div>
          <p className="text-[10px] text-[#8b8b9e] mt-1">{gamification?.xp_to_next} XP to next level</p>
        </div>

        <div className="stat-card">
          <div className="flex items-center gap-1.5 text-[#8b8b9e] text-xs mb-1">
            <CheckCircle className="w-3.5 h-3.5" />
            Completed
          </div>
          <p className="font-display text-2xl font-bold">{gamification?.stats?.sessions_completed || 0}</p>
          <p className="text-xs text-[#8b8b9e]">total sessions</p>
        </div>

        <div className="stat-card">
          <div className="flex items-center gap-1.5 text-[#8b8b9e] text-xs mb-1">
            <Clock className="w-3.5 h-3.5" />
            Studied
          </div>
          <p className="font-display text-2xl font-bold">{(gamification?.stats?.total_hours_studied || 0).toFixed(1)}h</p>
          <p className="text-xs text-[#8b8b9e]">total hours</p>
        </div>

        <div className="stat-card">
          <div className="flex items-center gap-1.5 text-[#8b8b9e] text-xs mb-1">
            <AlertCircle className="w-3.5 h-3.5" />
            Pending
          </div>
          <p className="font-display text-2xl font-bold">{assignments.length}</p>
          <p className="text-xs text-[#8b8b9e]">assignments</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        {/* Today's sessions */}
        <div className="lg:col-span-2 card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold flex items-center gap-2">
              <Zap className="w-4 h-4 text-brand-400" />
              Today's study plan
            </h2>
            <Link to="/calendar" className="text-xs text-brand-400 flex items-center gap-1 hover:text-brand-300">
              View all <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
          {sessions.length === 0 ? (
            <div className="text-center py-8">
              <Brain className="w-10 h-10 text-[#2e2e3e] mx-auto mb-3" />
              <p className="text-[#8b8b9e] text-sm">No sessions scheduled today</p>
              <Link to="/assignments" className="btn-primary text-sm mt-3 inline-block">Add assignments</Link>
            </div>
          ) : (
            <div className="space-y-2">
              {sessions.map(session => (
                <div key={session.id}
                  className={cn('flex items-center gap-3 p-3 rounded-xl border transition-all',
                    session.status === 'completed' ? 'opacity-50 border-[#2e2e3e] bg-[#22222f]/30' : 'border-[#2e2e3e] hover:border-brand-500/30 bg-[#22222f]/50')}>
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-lg flex-shrink-0"
                    style={{ background: session.subject_color ? `${session.subject_color}20` : '#6366f120' }}>
                    {SUBJECT_ICONS[session.subject_icon || 'default'] || '📚'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={cn('text-sm font-medium truncate', session.status === 'completed' && 'line-through text-[#8b8b9e]')}>{session.title}</p>
                    <p className="text-xs text-[#8b8b9e]">
                      {format(parseISO(session.scheduled_start), 'h:mm a')} · {session.duration_minutes}min
                      {session.subject_name && <span className="ml-1" style={{ color: session.subject_color }}>· {session.subject_name}</span>}
                    </p>
                  </div>
                  {session.status !== 'completed' ? (
                    <button onClick={() => completeSession(session.id)}
                      className="flex-shrink-0 text-xs bg-brand-500/10 hover:bg-brand-500/20 text-brand-400 px-3 py-1.5 rounded-lg font-medium transition-all">
                      Done ✓
                    </button>
                  ) : (
                    <span className="text-green-400 text-xs font-medium flex items-center gap-1"><CheckCircle className="w-3.5 h-3.5" /> +{session.xp_awarded} XP</span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right column */}
        <div className="space-y-4">
          {/* Due soon */}
          <div className="card p-5">
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-semibold text-sm">Upcoming deadlines</h2>
              <Link to="/assignments" className="text-xs text-brand-400"><ArrowRight className="w-3.5 h-3.5" /></Link>
            </div>
            <div className="space-y-2">
              {assignments.slice(0, 4).map(a => {
                const due = formatDueDate(a.due_date);
                return (
                  <div key={a.id} className="flex items-center gap-2.5">
                    <span className="text-base">{TYPE_CONFIG[a.type]?.emoji}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{a.title}</p>
                      <p className={cn('text-xs', due.color)}>{due.label}</p>
                    </div>
                    <span className={cn('badge border text-[10px]', PRIORITY_CONFIG[a.priority]?.className)}>
                      {PRIORITY_CONFIG[a.priority]?.label}
                    </span>
                  </div>
                );
              })}
              {assignments.length === 0 && <p className="text-xs text-[#8b8b9e] text-center py-2">No pending assignments</p>}
            </div>
          </div>

          {/* Reviews due */}
          {reviews.length > 0 && (
            <div className="card p-5 border-brand-500/20">
              <div className="flex items-center gap-2 mb-3">
                <Brain className="w-4 h-4 text-brand-400" />
                <h2 className="font-semibold text-sm">{reviews.length} reviews due today</h2>
              </div>
              <div className="space-y-2">
                {reviews.map(r => (
                  <div key={r.id} className="flex items-center gap-2 text-sm">
                    <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: r.subject_color || '#6366f1' }} />
                    <span className="truncate text-sm">{r.topic}</span>
                  </div>
                ))}
              </div>
              <Link to="/reviews" className="btn-primary text-xs mt-3 w-full text-center block py-2">
                Start reviews
              </Link>
            </div>
          )}

          {/* Achievements sneak peek */}
          {(gamification?.badges?.filter(b => b.earned) || []).length > 0 && (
            <div className="card p-5">
              <h2 className="font-semibold text-sm mb-3">Recent badges</h2>
              <div className="flex flex-wrap gap-2">
                {gamification!.badges.filter(b => b.earned).slice(0, 6).map(b => (
                  <div key={b.id} title={`${b.name}: ${b.desc}`}
                    className="w-10 h-10 rounded-xl bg-[#22222f] border border-[#2e2e3e] flex items-center justify-center text-xl cursor-help hover:scale-105 transition-transform">
                    {b.icon}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
