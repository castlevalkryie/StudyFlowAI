import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api, { useAuthStore } from '../lib/api';
import toast from 'react-hot-toast';

export default function Login() {
  const [form, setForm] = useState({ email: 'demo@studyflow.ai', password: 'demo1234' });
  const [loading, setLoading] = useState(false);
  const { setAuth } = useAuthStore();
  const navigate = useNavigate();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const r = await api.post('/auth/login', form);
      setAuth(r.data.user, r.data.token);
      toast.success(`Welcome back, ${r.data.user.name}!`);
      navigate('/dashboard');
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Login failed');
    } finally { setLoading(false); }
  };

  return (
    <div className="space-y-5">
      <div className="text-center">
        <h2 className="font-display text-xl font-bold">Welcome back</h2>
        <p className="text-[#8b8b9e] text-sm mt-1">Sign in to your study dashboard</p>
      </div>
      <form onSubmit={submit} className="space-y-4">
        <div>
          <label className="label">Email</label>
          <input type="email" className="input" placeholder="you@example.com" value={form.email}
            onChange={e => setForm(f => ({ ...f, email: e.target.value }))} required />
        </div>
        <div>
          <label className="label">Password</label>
          <input type="password" className="input" placeholder="••••••••" value={form.password}
            onChange={e => setForm(f => ({ ...f, password: e.target.value }))} required />
        </div>
        <button type="submit" className="btn-primary w-full py-3 mt-2" disabled={loading}>
          {loading ? 'Signing in...' : 'Sign in'}
        </button>
      </form>
      <div className="text-center">
        <p className="text-[#8b8b9e] text-sm">
          No account?{' '}
          <Link to="/register" className="text-brand-400 hover:text-brand-300 font-medium">Create one free</Link>
        </p>
      </div>
      <div className="mt-4 p-3 rounded-xl bg-[#22222f] border border-[#2e2e3e]">
        <p className="text-xs text-[#8b8b9e] text-center">
          Demo: <span className="text-[#f1f1f5] font-mono">demo@studyflow.ai</span> / <span className="text-[#f1f1f5] font-mono">demo1234</span>
        </p>
      </div>
    </div>
  );
}
