import { useEffect, useState } from 'react';
import { Plus, Search, Filter, Trash2, Check, ChevronDown } from 'lucide-react';
import api from '../lib/api';
import { cn, formatDueDate, PRIORITY_CONFIG, TYPE_CONFIG, SUBJECT_ICONS } from '../lib/utils';
import type { Assignment, Subject, AssignmentType, Priority } from '../types';
import toast from 'react-hot-toast';
import { format } from 'date-fns';

const EMPTY_FORM = { title: '', subject_id: '', type: 'homework' as AssignmentType, due_date: '', estimated_hours: 1, difficulty: 5, confidence: 5, priority: 'medium' as Priority, notes: '' };

export default function Assignments() {
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('pending');
  const [filterType, setFilterType] = useState('');

  useEffect(() => {
    load();
    api.get('/subjects').then(r => setSubjects(r.data));
  }, [filterStatus, filterType]);

  const load = async () => {
    const params = new URLSearchParams();
    if (filterStatus) params.set('status', filterStatus);
    if (filterType) params.set('type', filterType);
    const r = await api.get(`/assignments?${params}`);
    setAssignments(r.data);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title || !form.due_date) return toast.error('Title and due date are required');
    setSaving(true);
    try {
      await api.post('/assignments', form);
      toast.success('Assignment added!');
      setShowForm(false);
      setForm(EMPTY_FORM);
      load();
    } catch { toast.error('Failed to add'); } finally { setSaving(false); }
  };

  const complete = async (id: string) => {
    await api.patch(`/assignments/${id}`, { status: 'completed' });
    toast.success('+100 XP! Assignment complete 🎉');
    load();
  };

  const remove = async (id: string) => {
    if (!confirm('Delete this assignment?')) return;
    await api.delete(`/assignments/${id}`);
    toast.success('Deleted');
    load();
  };

  const SliderInput = ({ label, value, name, min = 1, max = 10 }: { label: string; value: number; name: string; min?: number; max?: number }) => (
    <div>
      <label className="label">{label}: <span className="text-brand-400 font-semibold">{value}/10</span></label>
      <input type="range" min={min} max={max} value={value} onChange={e => setForm(f => ({ ...f, [name]: +e.target.value }))}
        className="w-full h-2 bg-[#22222f] rounded-full appearance-none cursor-pointer accent-brand-500" />
      <div className="flex justify-between text-[10px] text-[#8b8b9e] mt-1">
        <span>{min === 1 ? 'Easy' : 'Low'}</span><span>{min === 1 ? 'Hard' : 'High'}</span>
      </div>
    </div>
  );

  const filtered = assignments.filter(a => !search || a.title.toLowerCase().includes(search.toLowerCase()) || a.subject_name?.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold">Assignments</h1>
          <p className="text-[#8b8b9e] text-sm mt-0.5">{filtered.length} items</p>
        </div>
        <button onClick={() => setShowForm(!showForm)} className={cn('btn-primary flex items-center gap-2', showForm && 'bg-[#22222f] text-[#f1f1f5]')}>
          <Plus className="w-4 h-4" /> Add assignment
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <form onSubmit={submit} className="card p-5 animate-slide-up space-y-4">
          <h3 className="font-semibold">New assignment</h3>
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="label">Title *</label>
              <input className="input" placeholder="e.g., Chapter 7 Problem Set" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} required />
            </div>
            <div>
              <label className="label">Subject</label>
              <select className="input" value={form.subject_id} onChange={e => setForm(f => ({ ...f, subject_id: e.target.value }))}>
                <option value="">No subject</option>
                {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Type</label>
              <select className="input" value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value as AssignmentType }))}>
                {Object.entries(TYPE_CONFIG).map(([k, v]) => <option key={k} value={k}>{v.emoji} {v.label}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Due date *</label>
              <input type="date" className="input" value={form.due_date} onChange={e => setForm(f => ({ ...f, due_date: e.target.value }))} required />
            </div>
            <div>
              <label className="label">Estimated hours</label>
              <input type="number" className="input" min={0.25} max={20} step={0.25} value={form.estimated_hours} onChange={e => setForm(f => ({ ...f, estimated_hours: +e.target.value }))} />
            </div>
            <div>
              <label className="label">Priority</label>
              <select className="input" value={form.priority} onChange={e => setForm(f => ({ ...f, priority: e.target.value as Priority }))}>
                {Object.entries(PRIORITY_CONFIG).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
              </select>
            </div>
            <SliderInput label="Difficulty" value={form.difficulty} name="difficulty" />
            <SliderInput label="Confidence" value={form.confidence} name="confidence" />
            <div className="sm:col-span-2">
              <label className="label">Notes</label>
              <textarea className="input resize-none" rows={2} placeholder="Any notes..." value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
            </div>
          </div>
          <div className="flex gap-3 justify-end">
            <button type="button" onClick={() => setShowForm(false)} className="btn-ghost">Cancel</button>
            <button type="submit" className="btn-primary" disabled={saving}>{saving ? 'Saving...' : 'Add assignment'}</button>
          </div>
        </form>
      )}

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        <div className="relative flex-1 min-w-[160px] max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8b8b9e]" />
          <input className="input pl-9" placeholder="Search..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        {(['', 'pending', 'in_progress', 'completed', 'missed'] as const).map(s => (
          <button key={s} onClick={() => setFilterStatus(s)}
            className={cn('px-3 py-2 rounded-xl text-sm font-medium border transition-all',
              filterStatus === s ? 'bg-brand-500/10 text-brand-400 border-brand-500/30' : 'border-[#2e2e3e] text-[#8b8b9e] hover:border-[#3e3e4e]')}>
            {s === '' ? 'All' : s.replace('_', ' ')}
          </button>
        ))}
      </div>

      {/* Assignment list */}
      <div className="space-y-2">
        {filtered.length === 0 ? (
          <div className="card p-10 text-center">
            <p className="text-4xl mb-3">📚</p>
            <p className="text-[#8b8b9e]">{filterStatus === 'pending' ? 'No pending assignments. Add one to get started!' : 'Nothing here yet.'}</p>
          </div>
        ) : filtered.map(a => {
          const due = formatDueDate(a.due_date);
          const subjectIcon = SUBJECT_ICONS[a.subject_icon || 'default'] || '📚';
          return (
            <div key={a.id} className={cn('card p-4 hover:border-brand-500/20 transition-all animate-fade-in', a.status === 'completed' && 'opacity-60')}>
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0"
                  style={{ background: a.subject_color ? `${a.subject_color}20` : '#6366f120' }}>
                  {TYPE_CONFIG[a.type]?.emoji}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <p className={cn('font-semibold', a.status === 'completed' && 'line-through text-[#8b8b9e]')}>{a.title}</p>
                    <span className={cn('badge border text-[10px]', PRIORITY_CONFIG[a.priority]?.className)}>{PRIORITY_CONFIG[a.priority]?.label}</span>
                    <span className={cn('badge text-[10px]', TYPE_CONFIG[a.type]?.className)}>{TYPE_CONFIG[a.type]?.label}</span>
                  </div>
                  <div className="flex flex-wrap gap-3 text-xs text-[#8b8b9e]">
                    {a.subject_name && <span style={{ color: a.subject_color }}>{subjectIcon} {a.subject_name}</span>}
                    <span className={due.color}>{due.label}</span>
                    <span>~{a.estimated_hours}h</span>
                    <span>Difficulty: {a.difficulty}/10</span>
                    <span>Confidence: {a.confidence}/10</span>
                  </div>
                </div>
                <div className="flex gap-2 flex-shrink-0">
                  {a.status !== 'completed' && (
                    <button onClick={() => complete(a.id)} className="p-2 rounded-lg bg-green-500/10 hover:bg-green-500/20 text-green-400 transition-all" title="Mark complete">
                      <Check className="w-4 h-4" />
                    </button>
                  )}
                  <button onClick={() => remove(a.id)} className="p-2 rounded-lg hover:bg-red-500/10 text-[#8b8b9e] hover:text-red-400 transition-all">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
