import { useEffect, useState } from 'react';
import api from '../lib/api';
import type { AnalyticsData } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, CartesianGrid } from 'recharts';
import { cn } from '../lib/utils';

const CHART_COLORS = ['#6366f1','#10b981','#f59e0b','#ec4899','#14b8a6','#8b5cf6','#ef4444'];

export default function Analytics() {
  const [data, setData] = useState<AnalyticsData | null>(null);

  useEffect(() => { api.get('/analytics/overview').then(r => setData(r.data)); }, []);

  if (!data) return <div className="flex items-center justify-center h-64"><div className="w-6 h-6 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" /></div>;

  const { stats, completion_rate, subject_breakdown, daily_activity, weekly_summary, xp_history } = data;

  const statusMap: Record<string, number> = {};
  data.assignment_stats.forEach(s => statusMap[s.status] = s.count);

  const TooltipStyle = { backgroundColor: '#1a1a24', border: '1px solid #2e2e3e', borderRadius: 8, color: '#f1f1f5', fontSize: 12 };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="font-display text-2xl font-bold">Analytics</h1>
        <p className="text-[#8b8b9e] text-sm mt-0.5">Your study performance overview</p>
      </div>

      {/* Top stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: 'Total hours', value: `${(stats?.total_hours_studied || 0).toFixed(1)}h`, sub: 'studied' },
          { label: 'Completion rate', value: `${completion_rate}%`, sub: 'sessions' },
          { label: 'Sessions done', value: stats?.sessions_completed || 0, sub: 'completed' },
          { label: 'Best streak', value: `${stats?.streak_longest || 0}d`, sub: 'days' },
        ].map(s => (
          <div key={s.label} className="stat-card">
            <p className="text-xs text-[#8b8b9e]">{s.label}</p>
            <p className="font-display text-2xl font-bold">{s.value}</p>
            <p className="text-xs text-[#8b8b9e]">{s.sub}</p>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        {/* Daily activity */}
        <div className="card p-5">
          <h2 className="font-semibold mb-4 text-sm">Daily activity (30 days)</h2>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={daily_activity} margin={{ left: -20 }}>
              <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#8b8b9e' }} tickFormatter={d => d.slice(8)} interval={4} />
              <YAxis tick={{ fontSize: 10, fill: '#8b8b9e' }} />
              <Tooltip contentStyle={TooltipStyle} formatter={(v, n) => [n === 'minutes' ? `${v}min` : v, n === 'completed' ? 'Completed' : 'Minutes']} />
              <Bar dataKey="completed" fill="#6366f1" radius={[3,3,0,0]} />
              <Bar dataKey="minutes" fill="#10b981" radius={[3,3,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Weekly hours */}
        <div className="card p-5">
          <h2 className="font-semibold mb-4 text-sm">Weekly study hours</h2>
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={weekly_summary} margin={{ left: -20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#2e2e3e" />
              <XAxis dataKey="week" tick={{ fontSize: 10, fill: '#8b8b9e' }} tickFormatter={w => `Wk ${w.split('-W')[1]}`} />
              <YAxis tick={{ fontSize: 10, fill: '#8b8b9e' }} />
              <Tooltip contentStyle={TooltipStyle} formatter={(v: any) => [`${Number(v).toFixed(1)}h`, 'Hours']} />
              <Line type="monotone" dataKey="hours" stroke="#6366f1" strokeWidth={2} dot={{ fill: '#6366f1', r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        {/* Subject breakdown */}
        <div className="card p-5">
          <h2 className="font-semibold mb-4 text-sm">By subject</h2>
          {subject_breakdown.length > 0 ? (
            <>
              <ResponsiveContainer width="100%" height={160}>
                <PieChart>
                  <Pie data={subject_breakdown} dataKey="hours_studied" cx="50%" cy="50%" outerRadius={60} paddingAngle={3}>
                    {subject_breakdown.map((s, i) => <Cell key={s.name} fill={s.color || CHART_COLORS[i % CHART_COLORS.length]} />)}
                  </Pie>
                  <Tooltip contentStyle={TooltipStyle} formatter={(v: any) => [`${Number(v).toFixed(1)}h`, 'Hours']} />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-1.5 mt-2">
                {subject_breakdown.map((s, i) => (
                  <div key={s.name} className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: s.color || CHART_COLORS[i % CHART_COLORS.length] }} />
                    <span className="text-xs flex-1 truncate">{s.name}</span>
                    <span className="text-xs text-[#8b8b9e]">{s.hours_studied.toFixed(1)}h</span>
                  </div>
                ))}
              </div>
            </>
          ) : <p className="text-[#8b8b9e] text-sm text-center py-8">No data yet</p>}
        </div>

        {/* Assignment stats */}
        <div className="card p-5">
          <h2 className="font-semibold mb-4 text-sm">Assignments</h2>
          <div className="space-y-3">
            {[
              { label: 'Completed', key: 'completed', color: 'bg-green-500' },
              { label: 'In progress', key: 'in_progress', color: 'bg-blue-500' },
              { label: 'Pending', key: 'pending', color: 'bg-yellow-500' },
              { label: 'Missed', key: 'missed', color: 'bg-red-500' },
            ].map(item => {
              const count = statusMap[item.key] || 0;
              const total = Object.values(statusMap).reduce((a, b) => a + b, 0) || 1;
              return (
                <div key={item.key}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-[#8b8b9e]">{item.label}</span>
                    <span className="font-medium">{count}</span>
                  </div>
                  <div className="h-2 bg-[#22222f] rounded-full overflow-hidden">
                    <div className={cn('h-full rounded-full transition-all', item.color)} style={{ width: `${(count / total) * 100}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* XP history */}
        <div className="card p-5">
          <h2 className="font-semibold mb-4 text-sm">Recent XP</h2>
          <div className="space-y-2 overflow-y-auto max-h-[240px]">
            {xp_history.length === 0 ? <p className="text-[#8b8b9e] text-sm text-center py-4">No XP earned yet</p>
              : xp_history.map((e, i) => (
                <div key={i} className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-xl bg-brand-500/10 flex items-center justify-center text-sm flex-shrink-0">
                    {e.event_type === 'session_complete' ? '✅' : e.event_type.includes('streak') ? '🔥' : e.event_type.includes('week') ? '🏆' : '⭐'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs truncate">{e.description}</p>
                    <p className="text-[10px] text-[#8b8b9e]">{new Date(e.created_at).toLocaleDateString()}</p>
                  </div>
                  <span className="text-xs font-bold text-brand-400 flex-shrink-0">+{e.xp_amount}</span>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}
