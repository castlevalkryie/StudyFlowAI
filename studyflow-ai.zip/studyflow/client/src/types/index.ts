export interface User {
  id: string;
  email: string;
  name: string;
  avatar_color: string;
  timezone: string;
  daily_study_hours: number;
  preferred_session_length: number;
  theme: 'dark' | 'light';
  stats?: UserStats;
}

export interface UserStats {
  user_id: string;
  xp_total: number;
  level: number;
  streak_current: number;
  streak_longest: number;
  last_study_date: string | null;
  sessions_completed: number;
  sessions_missed: number;
  total_hours_studied: number;
}

export interface Subject {
  id: string;
  name: string;
  color: string;
  icon: string;
  total_hours_studied: number;
}

export type AssignmentType = 'homework' | 'test' | 'quiz' | 'essay' | 'project' | 'review';
export type Priority = 'low' | 'medium' | 'high' | 'critical';
export type AssignmentStatus = 'pending' | 'in_progress' | 'completed' | 'missed';

export interface Assignment {
  id: string;
  subject_id: string | null;
  subject_name?: string;
  subject_color?: string;
  subject_icon?: string;
  title: string;
  type: AssignmentType;
  due_date: string;
  estimated_hours: number;
  difficulty: number;
  confidence: number;
  priority: Priority;
  status: AssignmentStatus;
  notes?: string;
  completed_at?: string;
  created_at: string;
}

export interface StudySession {
  id: string;
  assignment_id: string | null;
  subject_id: string | null;
  assignment_title?: string;
  assignment_type?: AssignmentType;
  subject_name?: string;
  subject_color?: string;
  subject_icon?: string;
  title: string;
  session_type: 'study' | 'review' | 'practice' | 'break';
  scheduled_start: string;
  scheduled_end: string;
  duration_minutes: number;
  status: 'scheduled' | 'completed' | 'missed' | 'skipped';
  xp_awarded: number;
  priority?: Priority;
}

export interface ReviewItem {
  id: string;
  assignment_id: string | null;
  subject_id: string | null;
  subject_name?: string;
  subject_color?: string;
  topic: string;
  next_review_date: string;
  review_count: number;
  ease_factor: number;
  interval_days: number;
  last_quality?: number;
}

export interface Badge {
  id: string;
  name: string;
  desc: string;
  icon: string;
  xp: number;
  earned: boolean;
  earned_at?: string;
}

export interface LevelInfo {
  level: number;
  name: string;
  min_xp: number;
  max_xp: number;
}

export interface GamificationStatus {
  stats: UserStats;
  level_info: LevelInfo;
  xp: number;
  xp_to_next: number;
  progress_pct: number;
  badges: Badge[];
}

export interface AnalyticsData {
  stats: UserStats;
  completion_rate: number;
  subject_breakdown: { name: string; color: string; sessions_completed: number; hours_studied: number }[];
  daily_activity: { date: string; total: number; completed: number; minutes: number }[];
  weekly_summary: { week: string; completed: number; hours: number }[];
  xp_history: { event_type: string; xp_amount: number; description: string; created_at: string }[];
  assignment_stats: { status: string; count: number }[];
}

export interface CoachMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  created_at: string;
}
