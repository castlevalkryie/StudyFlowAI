import axios from 'axios';
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User } from '../types';

const api = axios.create({ baseURL: '/api' });

api.interceptors.request.use(config => {
  const token = localStorage.getItem('sf_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(r => r, err => {
  if (err.response?.status === 401) {
    localStorage.removeItem('sf_token');
    window.location.href = '/login';
  }
  return Promise.reject(err);
});

export default api;

// Auth store
interface AuthState {
  user: User | null;
  token: string | null;
  setAuth: (user: User, token: string) => void;
  updateUser: (updates: Partial<User>) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      token: null,
      setAuth: (user, token) => {
        localStorage.setItem('sf_token', token);
        set({ user, token });
      },
      updateUser: (updates) => set(state => ({ user: state.user ? { ...state.user, ...updates } : null })),
      logout: () => {
        localStorage.removeItem('sf_token');
        set({ user: null, token: null });
      },
    }),
    { name: 'sf-auth', partialize: state => ({ user: state.user, token: state.token }) }
  )
);

// Theme store
interface ThemeState {
  theme: 'dark' | 'light';
  toggleTheme: () => void;
  setTheme: (t: 'dark' | 'light') => void;
}

export const useThemeStore = create<ThemeState>()(
  persist(
    (set) => ({
      theme: 'dark',
      toggleTheme: () => set(state => {
        const next = state.theme === 'dark' ? 'light' : 'dark';
        document.documentElement.classList.toggle('light', next === 'light');
        return { theme: next };
      }),
      setTheme: (theme) => {
        document.documentElement.classList.toggle('light', theme === 'light');
        set({ theme });
      },
    }),
    { name: 'sf-theme' }
  )
);
