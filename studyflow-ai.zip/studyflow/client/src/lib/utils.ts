import { clsx, type ClassValue } from 'clsx';
import { format, formatDistanceToNow, parseISO, differenceInDays, isToday, isTomorrow, isPast } from 'date-fns';
import type { Priority, AssignmentType } from '../types';

export function cn(...inputs: ClassValue[]) {
  return clsx(inputs);
}

export function formatDueDate(dateStr: string): { label: string; urgent: boolean; color: string } {
  const date = parseISO(dateStr);
  const days = differenceInDays(date, new Date());
  if (isPast(date)) return { label: 'Overdue', urgent: true, color: 'text-red-400' };
  if (isToday(date)) return { label: 'Due today', urgent: true, color: 'text-red-400' };
  if (isTomorrow(date)) return { label: 'Due tomorrow', urgent: true, color: 'text-orange-400' };
  if (days <= 3) return { label: `Due in ${days} days`, urgent: true, color: 'text-yellow-400' };
  if (days <= 7) return { label: `Due ${format(date, 'EEE')}`, urgent: false, color: 'text-blue-400' };
  return { label: format(date, 'MMM d'), urgent: false, color: 'text-[#8b8b9e]' };
}

export function formatSessionTime(start: string, end: string): string {
  return `${format(parseISO(start), 'h:mm a')} – ${format(parseISO(end), 'h:mm a')}`;
}

export const PRIORITY_CONFIG: Record<Priority, { label: string; className: string; dot: string }> = {
  critical: { label: 'Critical', className: 'priority-critical', dot: 'bg-red-400' },
  high: { label: 'High', className: 'priority-high', dot: 'bg-orange-400' },
  medium: { label: 'Medium', className: 'priority-medium', dot: 'bg-yellow-400' },
  low: { label: 'Low', className: 'priority-low', dot: 'bg-green-400' },
};

export const TYPE_CONFIG: Record<AssignmentType, { label: string; className: string; emoji: string }> = {
  homework: { label: 'Homework', className: 'type-homework', emoji: '📝' },
  test: { label: 'Test', className: 'type-test', emoji: '📋' },
  quiz: { label: 'Quiz', className: 'type-quiz', emoji: '✏️' },
  essay: { label: 'Essay', className: 'type-essay', emoji: '📄' },
  project: { label: 'Project', className: 'type-project', emoji: '🗂️' },
  review: { label: 'Review', className: 'bg-teal-500/10 text-teal-400', emoji: '🔁' },
};

export function getInitials(name: string): string {
  return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
}

export function getLevelColor(level: number): string {
  const colors = ['', '#10b981', '#6366f1', '#8b5cf6', '#f59e0b', '#ef4444'];
  return colors[level] || '#6366f1';
}

export function formatXP(xp: number): string {
  return xp >= 1000 ? `${(xp / 1000).toFixed(1)}k` : String(xp);
}

export const SUBJECT_ICONS: Record<string, string> = {
  calculator: '🧮', flask: '🧪', 'book-open': '📖', feather: '✍️',
  beaker: '⚗️', book: '📚', globe: '🌍', music: '🎵', palette: '🎨',
  code: '💻', atom: '⚛️', default: '📚',
};
