// subjects.js
const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../db/database');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

router.get('/', (req, res) => {
  const db = getDb();
  const subjects = db.prepare('SELECT * FROM subjects WHERE user_id = ? ORDER BY name').all(req.user.id);
  res.json(subjects);
});

router.post('/', (req, res) => {
  const { name, color, icon } = req.body;
  if (!name) return res.status(400).json({ error: 'name required' });
  const db = getDb();
  const id = uuidv4();
  db.prepare('INSERT INTO subjects (id, user_id, name, color, icon) VALUES (?,?,?,?,?)').run(id, req.user.id, name, color || '#6366f1', icon || 'book');
  res.status(201).json(db.prepare('SELECT * FROM subjects WHERE id=?').get(id));
});

router.patch('/:id', (req, res) => {
  const { name, color, icon } = req.body;
  const db = getDb();
  db.prepare('UPDATE subjects SET name=COALESCE(?,name), color=COALESCE(?,color), icon=COALESCE(?,icon) WHERE id=? AND user_id=?').run(name, color, icon, req.params.id, req.user.id);
  res.json({ ok: true });
});

router.delete('/:id', (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM subjects WHERE id=? AND user_id=?').run(req.params.id, req.user.id);
  res.json({ ok: true });
});

module.exports = router;
