const express = require('express');
const { getDb } = require('../db/database');
const { authenticate } = require('../middleware/auth');
const { processReview } = require('../services/spacedRepetition');

const router = express.Router();
router.use(authenticate);

router.get('/due', (req, res) => {
  const db = getDb();
  const today = new Date().toISOString().split('T')[0];
  const reviews = db.prepare(`SELECT r.*, s.name as subject_name, s.color as subject_color
    FROM review_items r LEFT JOIN subjects s ON r.subject_id = s.id
    WHERE r.user_id = ? AND r.next_review_date <= ? ORDER BY r.next_review_date ASC`)
    .all(req.user.id, today);
  res.json(reviews);
});

router.get('/', (req, res) => {
  const db = getDb();
  const reviews = db.prepare(`SELECT r.*, s.name as subject_name, s.color as subject_color
    FROM review_items r LEFT JOIN subjects s ON r.subject_id = s.id
    WHERE r.user_id = ? ORDER BY r.next_review_date ASC`).all(req.user.id);
  res.json(reviews);
});

router.post('/:id/complete', (req, res) => {
  const { quality } = req.body; // 0-5 quality rating
  const db = getDb();
  const item = db.prepare('SELECT * FROM review_items WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!item) return res.status(404).json({ error: 'Not found' });

  const updated = processReview(item, quality || 4);
  db.prepare(`UPDATE review_items SET next_review_date=?, interval_days=?, ease_factor=?, review_count=review_count+1, last_quality=? WHERE id=?`)
    .run(updated.next_review_date, updated.interval_days, updated.ease_factor, quality || 4, req.params.id);

  const { awardXP } = require('../services/gamification');
  awardXP(req.user.id, 'review_complete', 25, `Reviewed: ${item.topic}`);

  res.json(updated);
});

module.exports = router;
