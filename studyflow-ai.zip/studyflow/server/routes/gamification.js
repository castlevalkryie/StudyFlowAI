const express = require('express');
const { getDb } = require('../db/database');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

const BADGES = {
  first_session: { id: 'first_session', name: 'First Step', desc: 'Complete your first study session', icon: '🌱', xp: 100 },
  streak_3: { id: 'streak_3', name: 'Getting Started', desc: '3-day study streak', icon: '🔥', xp: 150 },
  streak_7: { id: 'streak_7', name: 'On Fire', desc: '7-day study streak', icon: '⚡', xp: 500 },
  streak_30: { id: 'streak_30', name: 'Unstoppable', desc: '30-day study streak', icon: '🏆', xp: 2000 },
  night_owl: { id: 'night_owl', name: 'Night Owl', desc: 'Study after 10pm', icon: '🦉', xp: 75 },
  early_bird: { id: 'early_bird', name: 'Early Bird', desc: 'Study before 7am', icon: '🐦', xp: 75 },
  week_warrior: { id: 'week_warrior', name: 'Week Warrior', desc: 'Complete a full week goal', icon: '⚔️', xp: 250 },
  subject_master: { id: 'subject_master', name: 'Subject Master', desc: '10 sessions in one subject', icon: '🎓', xp: 300 },
  review_champion: { id: 'review_champion', name: 'Review Champion', desc: 'Complete 10 spaced reviews', icon: '🧠', xp: 200 },
  perfect_week: { id: 'perfect_week', name: 'Perfect Week', desc: '0 missed sessions in a week', icon: '💎', xp: 400 },
};

const LEVELS = [
  { level: 1, name: 'Rookie Learner', min_xp: 0, max_xp: 500 },
  { level: 2, name: 'Focused Student', min_xp: 500, max_xp: 1500 },
  { level: 3, name: 'Scholar', min_xp: 1500, max_xp: 3500 },
  { level: 4, name: 'Academic Warrior', min_xp: 3500, max_xp: 7000 },
  { level: 5, name: 'Master Learner', min_xp: 7000, max_xp: Infinity },
];

router.get('/status', (req, res) => {
  const db = getDb();
  const stats = db.prepare('SELECT * FROM user_stats WHERE user_id = ?').get(req.user.id);
  const achievements = db.prepare('SELECT * FROM achievements WHERE user_id = ?').all(req.user.id);

  const xp = stats?.xp_total || 0;
  const levelInfo = LEVELS.find(l => xp >= l.min_xp && xp < l.max_xp) || LEVELS[LEVELS.length - 1];
  const nextLevel = LEVELS.find(l => l.level === levelInfo.level + 1);
  const xp_to_next = nextLevel ? nextLevel.min_xp - xp : 0;
  const progress_pct = nextLevel ? Math.round(((xp - levelInfo.min_xp) / (nextLevel.min_xp - levelInfo.min_xp)) * 100) : 100;

  const earnedBadgeIds = new Set(achievements.map(a => a.badge_id));
  const allBadges = Object.values(BADGES).map(b => ({ ...b, earned: earnedBadgeIds.has(b.id), earned_at: achievements.find(a => a.badge_id === b.id)?.earned_at }));

  res.json({ stats, level_info: levelInfo, xp, xp_to_next, progress_pct, badges: allBadges });
});

router.get('/leaderboard', (req, res) => {
  // Stub — in a real app, filter by school/friends
  res.json([]);
});

module.exports = router;
