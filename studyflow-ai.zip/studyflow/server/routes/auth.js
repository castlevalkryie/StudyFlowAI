const express = require('express');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../db/database');
const { authenticate, signToken } = require('../middleware/auth');

const router = express.Router();

router.post('/register', async (req, res) => {
  const { email, password, name } = req.body;
  if (!email || !password || !name) return res.status(400).json({ error: 'All fields required' });
  if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });

  const db = getDb();
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email.toLowerCase());
  if (existing) return res.status(409).json({ error: 'Email already registered' });

  const id = uuidv4();
  const hash = await bcrypt.hash(password, 10);
  const colors = ['#6366f1','#10b981','#f59e0b','#ec4899','#14b8a6','#8b5cf6'];
  const color = colors[Math.floor(Math.random() * colors.length)];

  db.prepare(`INSERT INTO users (id, email, password_hash, name, avatar_color) VALUES (?,?,?,?,?)`)
    .run(id, email.toLowerCase(), hash, name, color);
  db.prepare(`INSERT INTO user_stats (user_id) VALUES (?)`).run(id);

  const token = signToken({ id, email: email.toLowerCase(), name });
  res.status(201).json({ token, user: { id, email: email.toLowerCase(), name, avatar_color: color } });
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

  const db = getDb();
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase());
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });

  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) return res.status(401).json({ error: 'Invalid credentials' });

  const token = signToken({ id: user.id, email: user.email, name: user.name });
  const { password_hash, ...safe } = user;
  res.json({ token, user: safe });
});

router.get('/me', authenticate, (req, res) => {
  const db = getDb();
  const user = db.prepare('SELECT id,email,name,avatar_color,timezone,daily_study_hours,preferred_session_length,theme,created_at FROM users WHERE id = ?').get(req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  const stats = db.prepare('SELECT * FROM user_stats WHERE user_id = ?').get(req.user.id);
  res.json({ ...user, stats });
});

router.patch('/me', authenticate, (req, res) => {
  const { name, daily_study_hours, preferred_session_length, theme, timezone } = req.body;
  const db = getDb();
  db.prepare(`UPDATE users SET name=COALESCE(?,name), daily_study_hours=COALESCE(?,daily_study_hours),
    preferred_session_length=COALESCE(?,preferred_session_length), theme=COALESCE(?,theme),
    timezone=COALESCE(?,timezone), updated_at=datetime('now') WHERE id=?`)
    .run(name, daily_study_hours, preferred_session_length, theme, timezone, req.user.id);
  res.json({ ok: true });
});

module.exports = router;
