const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../db/database');
const { authenticate } = require('../middleware/auth');
const { scheduleAssignment } = require('../services/scheduler');
const { createReviewItems } = require('../services/spacedRepetition');

const router = express.Router();
router.use(authenticate);

router.get('/', (req, res) => {
  const db = getDb();
  const { status, type } = req.query;
  let query = `SELECT a.*, s.name as subject_name, s.color as subject_color, s.icon as subject_icon
    FROM assignments a LEFT JOIN subjects s ON a.subject_id = s.id
    WHERE a.user_id = ?`;
  const params = [req.user.id];
  if (status) { query += ' AND a.status = ?'; params.push(status); }
  if (type) { query += ' AND a.type = ?'; params.push(type); }
  query += ' ORDER BY a.due_date ASC, a.priority DESC';
  res.json(db.prepare(query).all(...params));
});

router.post('/', (req, res) => {
  const { title, subject_id, type, due_date, estimated_hours, difficulty, confidence, priority, notes } = req.body;
  if (!title || !type || !due_date) return res.status(400).json({ error: 'title, type, and due_date are required' });

  const db = getDb();
  const id = uuidv4();
  db.prepare(`INSERT INTO assignments (id, user_id, subject_id, title, type, due_date, estimated_hours, difficulty, confidence, priority, notes)
    VALUES (?,?,?,?,?,?,?,?,?,?,?)`)
    .run(id, req.user.id, subject_id || null, title, type, due_date, estimated_hours || 1, difficulty || 5, confidence || 5, priority || 'medium', notes || null);

  // Auto-schedule
  scheduleAssignment(req.user.id, id);
  // Set up spaced repetition for tests/quizzes
  if (['test', 'quiz'].includes(type)) {
    createReviewItems(req.user.id, id, title, subject_id);
  }

  const created = db.prepare('SELECT a.*, s.name as subject_name, s.color as subject_color FROM assignments a LEFT JOIN subjects s ON a.subject_id = s.id WHERE a.id = ?').get(id);
  res.status(201).json(created);
});

router.patch('/:id', (req, res) => {
  const db = getDb();
  const existing = db.prepare('SELECT * FROM assignments WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!existing) return res.status(404).json({ error: 'Not found' });

  const { title, subject_id, type, due_date, estimated_hours, difficulty, confidence, priority, notes, status } = req.body;
  const completedAt = status === 'completed' ? new Date().toISOString() : existing.completed_at;

  db.prepare(`UPDATE assignments SET
    title=COALESCE(?,title), subject_id=COALESCE(?,subject_id), type=COALESCE(?,type),
    due_date=COALESCE(?,due_date), estimated_hours=COALESCE(?,estimated_hours),
    difficulty=COALESCE(?,difficulty), confidence=COALESCE(?,confidence),
    priority=COALESCE(?,priority), notes=COALESCE(?,notes), status=COALESCE(?,status),
    completed_at=?, updated_at=datetime('now') WHERE id=?`)
    .run(title, subject_id, type, due_date, estimated_hours, difficulty, confidence, priority, notes, status, completedAt, req.params.id);

  if (status === 'completed') {
    const { awardXP } = require('../services/gamification');
    awardXP(req.user.id, 'assignment_complete', 100, `Completed: ${existing.title}`);
  }

  res.json(db.prepare('SELECT a.*, s.name as subject_name, s.color as subject_color FROM assignments a LEFT JOIN subjects s ON a.subject_id = s.id WHERE a.id = ?').get(req.params.id));
});

router.delete('/:id', (req, res) => {
  const db = getDb();
  const r = db.prepare('DELETE FROM assignments WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
  if (!r.changes) return res.status(404).json({ error: 'Not found' });
  res.json({ ok: true });
});

module.exports = router;
