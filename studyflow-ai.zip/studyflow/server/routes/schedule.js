const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../db/database');
const { authenticate } = require('../middleware/auth');
const { generateFullSchedule } = require('../services/scheduler');
const { awardXP } = require('../services/gamification');

const router = express.Router();
router.use(authenticate);

router.get('/', (req, res) => {
  const db = getDb();
  const { start, end } = req.query;
  let query = `SELECT ss.*, a.title as assignment_title, a.type as assignment_type, a.priority,
    s.name as subject_name, s.color as subject_color, s.icon as subject_icon
    FROM study_sessions ss
    LEFT JOIN assignments a ON ss.assignment_id = a.id
    LEFT JOIN subjects s ON ss.subject_id = s.id
    WHERE ss.user_id = ?`;
  const params = [req.user.id];
  if (start) { query += ' AND ss.scheduled_start >= ?'; params.push(start); }
  if (end) { query += ' AND ss.scheduled_start <= ?'; params.push(end); }
  query += ' ORDER BY ss.scheduled_start ASC';
  res.json(db.prepare(query).all(...params));
});

router.get('/today', (req, res) => {
  const db = getDb();
  const today = new Date().toISOString().split('T')[0];
  const sessions = db.prepare(`SELECT ss.*, a.title as assignment_title, a.type as assignment_type,
    a.difficulty, a.confidence, a.priority, s.name as subject_name, s.color as subject_color, s.icon as subject_icon
    FROM study_sessions ss
    LEFT JOIN assignments a ON ss.assignment_id = a.id
    LEFT JOIN subjects s ON ss.subject_id = s.id
    WHERE ss.user_id = ? AND date(ss.scheduled_start) = ?
    ORDER BY ss.scheduled_start ASC`).all(req.user.id, today);
  res.json(sessions);
});

router.post('/generate', (req, res) => {
  const sessions = generateFullSchedule(req.user.id);
  res.json({ generated: sessions.length, sessions });
});

router.patch('/:id/complete', (req, res) => {
  const db = getDb();
  const session = db.prepare('SELECT * FROM study_sessions WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!session) return res.status(404).json({ error: 'Not found' });

  const xp = 50;
  db.prepare(`UPDATE study_sessions SET status='completed', actual_end=datetime('now'), xp_awarded=? WHERE id=?`).run(xp, req.params.id);
  awardXP(req.user.id, 'session_complete', xp, 'Completed a study session');

  const stats = db.prepare('SELECT * FROM user_stats WHERE user_id = ?').get(req.user.id);
  const today = new Date().toISOString().split('T')[0];
  const lastDate = stats?.last_study_date;
  const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
  const newStreak = (lastDate === yesterday || lastDate === today) ? (stats?.streak_current || 0) + (lastDate === today ? 0 : 1) : 1;
  const longest = Math.max(newStreak, stats?.streak_longest || 0);

  db.prepare(`UPDATE user_stats SET sessions_completed=sessions_completed+1, streak_current=?,
    streak_longest=?, last_study_date=?, total_hours_studied=total_hours_studied+?,
    updated_at=datetime('now') WHERE user_id=?`)
    .run(newStreak, longest, today, session.duration_minutes / 60, req.user.id);

  // Streak bonuses
  if (newStreak === 7) awardXP(req.user.id, 'streak_7', 500, '7-day streak! 🔥');
  if (newStreak === 30) awardXP(req.user.id, 'streak_30', 2000, '30-day streak! 🏆');

  res.json({ ok: true, xp_awarded: xp, new_streak: newStreak });
});

router.patch('/:id/miss', (req, res) => {
  const db = getDb();
  db.prepare(`UPDATE study_sessions SET status='missed' WHERE id = ? AND user_id = ?`).run(req.params.id, req.user.id);
  db.prepare(`UPDATE user_stats SET sessions_missed=sessions_missed+1, streak_current=0, updated_at=datetime('now') WHERE user_id=?`).run(req.user.id);
  res.json({ ok: true });
});

router.patch('/:id/move', (req, res) => {
  const { scheduled_start, scheduled_end } = req.body;
  if (!scheduled_start || !scheduled_end) return res.status(400).json({ error: 'scheduled_start and scheduled_end required' });
  const db = getDb();
  db.prepare('UPDATE study_sessions SET scheduled_start=?, scheduled_end=? WHERE id=? AND user_id=?')
    .run(scheduled_start, scheduled_end, req.params.id, req.user.id);
  res.json({ ok: true });
});

module.exports = router;
