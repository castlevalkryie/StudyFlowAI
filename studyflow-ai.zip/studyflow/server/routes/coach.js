const express = require('express');
const { getDb } = require('../db/database');
const { authenticate } = require('../middleware/auth');
const { generateCoachResponse } = require('../services/coach');

const router = express.Router();
router.use(authenticate);

router.get('/history', (req, res) => {
  const db = getDb();
  const messages = db.prepare('SELECT * FROM coach_messages WHERE user_id = ? ORDER BY created_at ASC LIMIT 50').all(req.user.id);
  res.json(messages);
});

router.post('/message', async (req, res) => {
  const { message } = req.body;
  if (!message) return res.status(400).json({ error: 'message required' });

  const db = getDb();
  const { v4: uuidv4 } = require('uuid');

  // Save user message
  db.prepare('INSERT INTO coach_messages (id, user_id, role, content) VALUES (?,?,?,?)').run(uuidv4(), req.user.id, 'user', message);

  // Get context
  const stats = db.prepare('SELECT * FROM user_stats WHERE user_id = ?').get(req.user.id);
  const upcoming = db.prepare(`SELECT a.*, s.name as subject_name FROM assignments a LEFT JOIN subjects s ON a.subject_id = s.id WHERE a.user_id = ? AND a.status='pending' ORDER BY a.due_date ASC LIMIT 5`).all(req.user.id);
  const weakSubjects = db.prepare(`SELECT s.name, AVG(a.confidence) as avg_conf FROM subjects s JOIN assignments a ON a.subject_id=s.id WHERE s.user_id=? AND a.status!='completed' GROUP BY s.id HAVING avg_conf < 5 ORDER BY avg_conf ASC LIMIT 3`).all(req.user.id);
  const history = db.prepare('SELECT role, content FROM coach_messages WHERE user_id = ? ORDER BY created_at DESC LIMIT 10').all(req.user.id).reverse();

  const context = { stats, upcoming_assignments: upcoming, weak_subjects: weakSubjects };
  const response = generateCoachResponse(message, context, history);

  db.prepare('INSERT INTO coach_messages (id, user_id, role, content) VALUES (?,?,?,?)').run(uuidv4(), req.user.id, 'assistant', response);
  res.json({ response });
});

router.delete('/history', (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM coach_messages WHERE user_id = ?').run(req.user.id);
  res.json({ ok: true });
});

module.exports = router;
