const express = require('express');
const { getDb } = require('../db/database');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

router.get('/overview', (req, res) => {
  const db = getDb();
  const uid = req.user.id;

  const stats = db.prepare('SELECT * FROM user_stats WHERE user_id = ?').get(uid);
  const completionRate = stats?.sessions_completed
    ? Math.round(stats.sessions_completed / (stats.sessions_completed + stats.sessions_missed) * 100)
    : 0;

  // Subject breakdown
  const subjectBreakdown = db.prepare(`
    SELECT s.name, s.color,
      COUNT(CASE WHEN ss.status='completed' THEN 1 END) as sessions_completed,
      SUM(CASE WHEN ss.status='completed' THEN ss.duration_minutes ELSE 0 END) / 60.0 as hours_studied
    FROM subjects s
    LEFT JOIN study_sessions ss ON ss.subject_id = s.id AND ss.user_id = ?
    WHERE s.user_id = ?
    GROUP BY s.id ORDER BY hours_studied DESC`).all(uid, uid);

  // Daily activity last 30 days
  const dailyActivity = db.prepare(`
    SELECT date(scheduled_start) as date,
      COUNT(*) as total,
      COUNT(CASE WHEN status='completed' THEN 1 END) as completed,
      SUM(CASE WHEN status='completed' THEN duration_minutes ELSE 0 END) as minutes
    FROM study_sessions WHERE user_id = ? AND scheduled_start >= date('now', '-30 days')
    GROUP BY date(scheduled_start) ORDER BY date ASC`).all(uid);

  // Weekly summary (last 8 weeks)
  const weekly = db.prepare(`
    SELECT strftime('%Y-W%W', scheduled_start) as week,
      COUNT(CASE WHEN status='completed' THEN 1 END) as completed,
      SUM(CASE WHEN status='completed' THEN duration_minutes ELSE 0 END) / 60.0 as hours
    FROM study_sessions WHERE user_id = ? AND scheduled_start >= date('now', '-56 days')
    GROUP BY week ORDER BY week ASC`).all(uid);

  // XP history
  const xpHistory = db.prepare(`SELECT * FROM xp_events WHERE user_id = ? ORDER BY created_at DESC LIMIT 20`).all(uid);

  // Assignments overview
  const assignmentStats = db.prepare(`
    SELECT status, COUNT(*) as count FROM assignments WHERE user_id = ? GROUP BY status`).all(uid);

  res.json({
    stats,
    completion_rate: completionRate,
    subject_breakdown: subjectBreakdown,
    daily_activity: dailyActivity,
    weekly_summary: weekly,
    xp_history: xpHistory,
    assignment_stats: assignmentStats,
  });
});

router.get('/weak-subjects', (req, res) => {
  const db = getDb();
  const weak = db.prepare(`
    SELECT s.name, s.color, AVG(a.confidence) as avg_confidence, AVG(a.difficulty) as avg_difficulty,
      COUNT(a.id) as assignment_count
    FROM subjects s
    JOIN assignments a ON a.subject_id = s.id
    WHERE s.user_id = ? AND a.status != 'completed'
    GROUP BY s.id HAVING avg_confidence < 6
    ORDER BY avg_confidence ASC LIMIT 5`).all(req.user.id);
  res.json(weak);
});

module.exports = router;
