const { getDb } = require('../db/database');
const { v4: uuidv4 } = require('uuid');
const { addDays, format } = require('date-fns');

// SM-2 Spaced Repetition Algorithm
// quality: 0-5 (0=blackout, 3=correct with difficulty, 5=perfect)
function processReview(item, quality) {
  let { ease_factor, interval_days, review_count } = item;
  ease_factor = ease_factor || 2.5;
  interval_days = interval_days || 1;
  review_count = review_count || 0;

  if (quality < 3) {
    // Failed — reset to beginning
    interval_days = 1;
  } else {
    if (review_count === 0) interval_days = 1;
    else if (review_count === 1) interval_days = 3;
    else interval_days = Math.round(interval_days * ease_factor);
  }

  // Adjust ease factor
  ease_factor = Math.max(1.3, ease_factor + 0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02));

  const next_review_date = format(addDays(new Date(), interval_days), 'yyyy-MM-dd');
  return { next_review_date, interval_days, ease_factor };
}

// The classic spaced repetition schedule: 1, 3, 7, 14, 30 days
const REVIEW_INTERVALS = [1, 3, 7, 14, 30];

function createReviewItems(userId, assignmentId, topic, subjectId) {
  const db = getDb();
  // Create initial review due tomorrow
  const id = uuidv4();
  const nextReview = format(addDays(new Date(), 1), 'yyyy-MM-dd');
  db.prepare(`INSERT OR IGNORE INTO review_items (id, user_id, assignment_id, subject_id, topic, next_review_date, interval_days)
    VALUES (?,?,?,?,?,?,?)`)
    .run(id, userId, assignmentId, subjectId || null, topic, nextReview, 1);
}

module.exports = { processReview, createReviewItems, REVIEW_INTERVALS };
