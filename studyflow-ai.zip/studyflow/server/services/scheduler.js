const { getDb } = require('../db/database');
const { v4: uuidv4 } = require('uuid');
const { addDays, format, parseISO, differenceInDays, startOfDay, isBefore, isAfter, addMinutes } = require('date-fns');

/**
 * Priority score for an assignment — higher = schedule sooner & more
 */
function calcPriorityScore(assignment) {
  const daysUntilDue = differenceInDays(parseISO(assignment.due_date), new Date());
  const urgency = daysUntilDue <= 1 ? 10 : daysUntilDue <= 3 ? 8 : daysUntilDue <= 7 ? 5 : 2;
  const difficultyWeight = assignment.difficulty / 10;
  const confidenceWeight = (10 - assignment.confidence) / 10; // Low confidence = higher priority
  const priorityMultiplier = { critical: 2.0, high: 1.5, medium: 1.0, low: 0.6 }[assignment.priority] || 1;
  return (urgency * 0.4 + difficultyWeight * 3 * 0.3 + confidenceWeight * 3 * 0.3) * priorityMultiplier;
}

/**
 * Allocate study hours per assignment based on priority scores
 */
function allocateHours(assignments, availableHours) {
  const scored = assignments.map(a => ({ ...a, score: calcPriorityScore(a) }));
  const totalScore = scored.reduce((s, a) => s + a.score, 0) || 1;
  return scored.map(a => ({
    ...a,
    allocated_hours: Math.min(a.estimated_hours, (a.score / totalScore) * availableHours),
  }));
}

/**
 * Generate study sessions for a single assignment
 */
function scheduleAssignment(userId, assignmentId) {
  const db = getDb();
  const assignment = db.prepare('SELECT a.*, s.name as subject_name FROM assignments a LEFT JOIN subjects s ON a.subject_id=s.id WHERE a.id=? AND a.user_id=?').get(assignmentId, userId);
  if (!assignment || assignment.status === 'completed') return;

  const user = db.prepare('SELECT * FROM users WHERE id=?').get(userId);
  const sessionLen = user.preferred_session_length || 25;
  const dailyHours = user.daily_study_hours || 2;

  const daysUntilDue = differenceInDays(parseISO(assignment.due_date), new Date());
  const studyDays = Math.max(1, Math.min(daysUntilDue, Math.ceil(assignment.estimated_hours / dailyHours * 2)));
  const hoursPerDay = assignment.estimated_hours / studyDays;

  // Remove old scheduled sessions for this assignment
  db.prepare("DELETE FROM study_sessions WHERE assignment_id=? AND user_id=? AND status='scheduled'").run(assignmentId, userId);

  for (let dayOffset = 0; dayOffset < studyDays; dayOffset++) {
    const sessionDate = addDays(new Date(), dayOffset);
    if (isBefore(parseISO(assignment.due_date), sessionDate)) break;

    const baseHour = 16; // 4 PM default study time
    const start = `${format(sessionDate, 'yyyy-MM-dd')}T${String(baseHour).padStart(2,'0')}:00:00`;
    const durationMins = Math.round(hoursPerDay * 60);
    const end = format(addMinutes(parseISO(start), durationMins), "yyyy-MM-dd'T'HH:mm:ss");

    db.prepare(`INSERT INTO study_sessions (id, user_id, assignment_id, subject_id, title, session_type, scheduled_start, scheduled_end, duration_minutes)
      VALUES (?,?,?,?,?,?,?,?,?)`)
      .run(uuidv4(), userId, assignmentId, assignment.subject_id,
        `Study: ${assignment.title}`, assignment.type === 'test' || assignment.type === 'quiz' ? 'practice' : 'study',
        start, end, durationMins);
  }
}

/**
 * Regenerate the full schedule for a user (called on demand or daily cron)
 */
function generateFullSchedule(userId) {
  const db = getDb();
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(userId);
  const pendingAssignments = db.prepare(`SELECT a.*, s.name as subject_name FROM assignments a LEFT JOIN subjects s ON a.subject_id=s.id WHERE a.user_id=? AND a.status IN ('pending','in_progress') AND a.due_date >= date('now') ORDER BY a.due_date ASC`).all(userId);

  if (!pendingAssignments.length) return [];

  // Clear future scheduled sessions
  db.prepare("DELETE FROM study_sessions WHERE user_id=? AND status='scheduled' AND scheduled_start > datetime('now')").run(userId);

  const dailyHours = user?.daily_study_hours || 2;
  const sessionLen = user?.preferred_session_length || 25;
  const allocations = allocateHours(pendingAssignments, dailyHours * 7); // Plan for 7 days

  const createdSessions = [];
  const now = new Date();

  allocations.forEach((assignment) => {
    if (assignment.allocated_hours < 0.25) return;
    const daysUntilDue = Math.max(1, differenceInDays(parseISO(assignment.due_date), now));
    const studyDays = Math.min(daysUntilDue, Math.ceil(assignment.allocated_hours));
    const minsPerDay = Math.ceil((assignment.allocated_hours / studyDays) * 60);

    for (let d = 0; d < studyDays; d++) {
      const sessionDate = addDays(now, d);
      const baseHour = 16 + (createdSessions.filter(s => s.date === format(sessionDate, 'yyyy-MM-dd')).length * 2);
      const start = `${format(sessionDate, 'yyyy-MM-dd')}T${Math.min(baseHour, 21).toString().padStart(2,'0')}:00:00`;
      const end = format(addMinutes(parseISO(start), Math.min(minsPerDay, 120)), "yyyy-MM-dd'T'HH:mm:ss");
      const id = uuidv4();
      db.prepare(`INSERT OR IGNORE INTO study_sessions (id,user_id,assignment_id,subject_id,title,session_type,scheduled_start,scheduled_end,duration_minutes) VALUES (?,?,?,?,?,?,?,?,?)`)
        .run(id, userId, assignment.id, assignment.subject_id, `Study: ${assignment.title}`,
          ['test','quiz'].includes(assignment.type) ? 'practice' : 'study', start, end, Math.min(minsPerDay, 120));
      createdSessions.push({ id, date: format(sessionDate, 'yyyy-MM-dd') });
    }
  });

  return createdSessions;
}

module.exports = { scheduleAssignment, generateFullSchedule, calcPriorityScore };
