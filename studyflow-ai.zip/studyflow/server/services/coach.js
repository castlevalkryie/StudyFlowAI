const { differenceInDays, parseISO } = require('date-fns');

/**
 * StudyFlow Coach — intelligent rule-based response engine.
 * Architecture is structured for easy LLM API swap-in.
 * 
 * To upgrade to real AI: replace generateCoachResponse body with:
 *   const response = await openai.chat.completions.create({ model:'gpt-4o', messages: buildMessages(context, history, userMessage) })
 *   return response.choices[0].message.content
 */

const STRATEGIES = {
  pomodoro: "Try the **Pomodoro Technique**: study for 25 minutes, then take a 5-minute break. After 4 rounds, take a longer 15-minute break. This keeps focus sharp and prevents burnout.",
  active_recall: "Instead of re-reading your notes, try **active recall**: close your notes and write down everything you remember about the topic. This is one of the most effective study methods backed by research.",
  spaced_repetition: "**Spaced repetition** works by reviewing material at increasing intervals (1 day, 3 days, 7 days, 14 days). Your reviews are already scheduled — make sure to complete them!",
  feynman: "Use the **Feynman Technique**: explain the concept in simple terms as if teaching it to someone else. Wherever you get stuck, that's exactly what you need to study more.",
  mind_mapping: "Try **mind mapping** for complex topics — start with the main concept in the center and branch out to subtopics. This helps connect ideas and improves retention.",
};

function detectIntent(message) {
  const m = message.toLowerCase();
  if (m.includes('what') && (m.includes('study') || m.includes('next'))) return 'what_to_study';
  if (m.includes('strategy') || m.includes('technique') || m.includes('how to study')) return 'study_strategy';
  if (m.includes('motivat') || m.includes('tired') || m.includes('can\'t focus') || m.includes('stressed')) return 'motivation';
  if (m.includes('weak') || m.includes('struggle') || m.includes('hard') || m.includes('difficult')) return 'weak_subject';
  if (m.includes('schedule') || m.includes('plan') || m.includes('organize')) return 'schedule';
  if (m.includes('review') || m.includes('remember') || m.includes('forgot')) return 'review';
  if (m.includes('test') || m.includes('exam') || m.includes('quiz')) return 'test_prep';
  if (m.includes('break') || m.includes('rest')) return 'break';
  if (m.includes('hello') || m.includes('hi') || m.includes('hey')) return 'greeting';
  return 'general';
}

function generateCoachResponse(userMessage, context, history = []) {
  const intent = detectIntent(userMessage);
  const { stats, upcoming_assignments = [], weak_subjects = [] } = context;

  const streak = stats?.streak_current || 0;
  const level = stats?.level || 1;
  const nextUp = upcoming_assignments[0];
  const mostUrgent = upcoming_assignments.find(a => a.priority === 'critical') || nextUp;

  switch (intent) {
    case 'greeting':
      return `Hey there! 👋 I'm your StudyFlow Coach. ${streak > 0 ? `Great job keeping a **${streak}-day streak**!` : 'Ready to start your study journey?'} What can I help you with today? I can suggest what to study next, share strategies, or help you plan your week.`;

    case 'what_to_study':
      if (!mostUrgent) return "You're all caught up! 🎉 Great work. Now is a perfect time to do some review sessions to reinforce what you've already learned.";
      const days = differenceInDays(parseISO(mostUrgent.due_date), new Date());
      const urgencyText = days <= 1 ? '**due tomorrow** — this is your top priority!' : days <= 3 ? `due in ${days} days — focus here first.` : `due in ${days} days.`;
      return `Based on your schedule, I'd recommend studying **${mostUrgent.title}** (${mostUrgent.subject_name}) — it's ${urgencyText}\n\n${mostUrgent.confidence <= 4 ? `Your confidence on this topic is low (${mostUrgent.confidence}/10), so extra review time will pay off. ` : ''}${STRATEGIES.active_recall}`;

    case 'study_strategy':
      const strategies = Object.values(STRATEGIES);
      const strategy = strategies[Math.floor(Math.random() * strategies.length)];
      return `Here's a research-backed strategy for you:\n\n${strategy}\n\nWant me to suggest a specific technique for one of your upcoming assignments?`;

    case 'motivation':
      const levelNames = ['', 'Rookie Learner', 'Focused Student', 'Scholar', 'Academic Warrior', 'Master Learner'];
      return `I hear you — studying is tough sometimes. 💪 But look at what you've already done: you're a **Level ${level} ${levelNames[level]}** with a **${streak}-day streak**!\n\nRemember: every expert was once a beginner. Even 20 focused minutes today is better than nothing. Try this: set a timer for just 10 minutes and start your highest-priority task. Once you start, it's much easier to keep going.\n\n${STRATEGIES.pomodoro}`;

    case 'weak_subject':
      if (weak_subjects.length > 0) {
        const subject = weak_subjects[0];
        return `I can see from your data that **${subject.name}** has an average confidence of ${Math.round(subject.avg_conf)}/10 — that's where extra effort will make the biggest difference.\n\nMy recommendation: schedule 30–45 minutes of focused review on ${subject.name} today. Use active recall: put your notes away and try to recall key concepts from memory. This feels harder but builds stronger memory.\n\n${STRATEGIES.feynman}`;
      }
      return `Looking at your assignments, try focusing on subjects where your confidence rating is lowest. ${weak_subjects.length === 0 ? "You're doing great overall! Keep up your spaced reviews to maintain retention." : ''}`;

    case 'test_prep':
      return `For test prep, here's a proven 3-step approach:\n\n1. **Active recall**: Cover your notes and write down key facts from memory\n2. **Practice problems**: Do as many practice questions as you can find\n3. **Teach it**: Explain the material out loud as if teaching someone\n\n${STRATEGIES.spaced_repetition}\n\nMake sure you're completing your scheduled review sessions — they're calibrated to your upcoming tests!`;

    case 'review':
      return `**Spaced repetition is your superpower.** 🧠\n\nYour brain forgets in a predictable curve, but reviewing at the right intervals (1 day, 3 days, 7 days, 14 days, 30 days) resets that curve each time.\n\nCheck your **Reviews** section — you likely have items due today. Completing them takes just a few minutes but dramatically improves long-term retention.\n\n${STRATEGIES.active_recall}`;

    case 'schedule':
      return `Your study schedule is automatically generated based on:\n• **Due dates** and urgency\n• **Difficulty** ratings\n• **Confidence** levels (lower confidence = more time allocated)\n• **Priority** settings\n\nYou can adjust any session by dragging it on the calendar. If you miss a session, the planner automatically redistributes that time.\n\nTip: Be honest with your confidence ratings — lower confidence correctly triggers more study time on hard topics!`;

    case 'break':
      return `Absolutely take a break! ☕ Rest is not laziness — it's part of effective studying.\n\nThe science: your brain consolidates memories during rest and sleep. After a 10-15 minute break, you'll return with sharper focus.\n\n**Break ideas**: stretch, grab water, take a short walk outside. Avoid scrolling social media — it doesn't give your brain the same reset.\n\nCome back ready to tackle **${nextUp?.title || 'your next task'}**! 💪`;

    default:
      const tips = [
        `Keep up that **${streak}-day streak**! Consistency is the most powerful study tool.`,
        `${mostUrgent ? `Your most urgent task is **${mostUrgent.title}** — want tips for tackling it?` : "You're looking good on assignments!"}`,
        "Try asking me: 'What should I study next?', 'Give me a study strategy', or 'Help me prepare for my test'.",
      ];
      return `I'm here to help you study smarter! 🎓\n\n${tips[Math.floor(Math.random() * tips.length)]}\n\nWhat would you like help with?`;
  }
}

module.exports = { generateCoachResponse };
