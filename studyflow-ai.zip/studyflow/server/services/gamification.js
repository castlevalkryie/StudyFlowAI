const { getDb } = require('../db/database');
const { v4: uuidv4 } = require('uuid');

const LEVELS = [
  { level: 1, name: 'Rookie Learner', min_xp: 0 },
  { level: 2, name: 'Focused Student', min_xp: 500 },
  { level: 3, name: 'Scholar', min_xp: 1500 },
  { level: 4, name: 'Academic Warrior', min_xp: 3500 },
  { level: 5, name: 'Master Learner', min_xp: 7000 },
];

function getLevel(xp) {
  for (let i = LEVELS.length - 1; i >= 0; i--) {
    if (xp >= LEVELS[i].min_xp) return LEVELS[i];
  }
  return LEVELS[0];
}

function awardXP(userId, eventType, amount, description) {
  const db = getDb();
  db.prepare('INSERT INTO xp_events (id, user_id, event_type, xp_amount, description) VALUES (?,?,?,?,?)').run(uuidv4(), userId, eventType, amount, description);
  const result = db.prepare('UPDATE user_stats SET xp_total=xp_total+? WHERE user_id=?').run(amount, userId);
  const stats = db.prepare('SELECT xp_total FROM user_stats WHERE user_id=?').get(userId);
  if (stats) {
    const levelInfo = getLevel(stats.xp_total);
    db.prepare('UPDATE user_stats SET level=? WHERE user_id=?').run(levelInfo.level, userId);
  }
  return result;
}

function awardBadge(userId, badgeId) {
  const db = getDb();
  try {
    db.prepare('INSERT OR IGNORE INTO achievements (id, user_id, badge_id) VALUES (?,?,?)').run(uuidv4(), userId, badgeId);
  } catch {}
}

module.exports = { awardXP, awardBadge, getLevel, LEVELS };
