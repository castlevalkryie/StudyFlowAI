require('dotenv').config({ path: '../.env' });
const { initDb, getDb } = require('./database');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { addDays, format, subDays } = require('date-fns');

async function seed() {
  initDb();
  const db = getDb();

  const userId = uuidv4();
  const hash = await bcrypt.hash('demo1234', 10);
  const now = new Date();

  // Demo user
  db.prepare(`INSERT OR REPLACE INTO users (id, email, password_hash, name, avatar_color, daily_study_hours)
    VALUES (?, ?, ?, ?, ?, ?)`).run(userId, 'demo@studyflow.ai', hash, 'Alex Rivera', '#6366f1', 3);

  // User stats
  db.prepare(`INSERT OR REPLACE INTO user_stats (user_id, xp_total, level, streak_current, streak_longest, last_study_date, sessions_completed, total_hours_studied)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).run(userId, 1840, 3, 7, 12, format(subDays(now, 0), 'yyyy-MM-dd'), 42, 38.5);

  // Subjects
  const subjects = [
    { id: uuidv4(), name: 'Algebra II', color: '#6366f1', icon: 'calculator' },
    { id: uuidv4(), name: 'AP Biology', color: '#10b981', icon: 'flask' },
    { id: uuidv4(), name: 'U.S. History', color: '#f59e0b', icon: 'book-open' },
    { id: uuidv4(), name: 'English Lit', color: '#ec4899', icon: 'feather' },
    { id: uuidv4(), name: 'Chemistry', color: '#14b8a6', icon: 'beaker' },
  ];

  for (const s of subjects) {
    db.prepare(`INSERT OR REPLACE INTO subjects (id, user_id, name, color, icon) VALUES (?,?,?,?,?)`)
      .run(s.id, userId, s.name, s.color, s.icon);
  }

  // Assignments
  const assignments = [
    { id: uuidv4(), subject_id: subjects[0].id, title: 'Chapter 7 Problem Set', type: 'homework', due_date: format(addDays(now, 2), 'yyyy-MM-dd'), estimated_hours: 1.5, difficulty: 7, confidence: 4, priority: 'high' },
    { id: uuidv4(), subject_id: subjects[1].id, title: 'AP Bio Midterm Exam', type: 'test', due_date: format(addDays(now, 5), 'yyyy-MM-dd'), estimated_hours: 6, difficulty: 9, confidence: 3, priority: 'critical' },
    { id: uuidv4(), subject_id: subjects[2].id, title: 'WWI Essay Draft', type: 'essay', due_date: format(addDays(now, 8), 'yyyy-MM-dd'), estimated_hours: 4, difficulty: 6, confidence: 6, priority: 'medium' },
    { id: uuidv4(), subject_id: subjects[0].id, title: 'Quadratic Functions Quiz', type: 'quiz', due_date: format(addDays(now, 3), 'yyyy-MM-dd'), estimated_hours: 2, difficulty: 6, confidence: 5, priority: 'high' },
    { id: uuidv4(), subject_id: subjects[3].id, title: 'The Great Gatsby Analysis', type: 'essay', due_date: format(addDays(now, 14), 'yyyy-MM-dd'), estimated_hours: 5, difficulty: 5, confidence: 7, priority: 'medium' },
    { id: uuidv4(), subject_id: subjects[4].id, title: 'Lab Report: Titration', type: 'homework', due_date: format(addDays(now, 4), 'yyyy-MM-dd'), estimated_hours: 2.5, difficulty: 7, confidence: 4, priority: 'high' },
    { id: uuidv4(), subject_id: subjects[1].id, title: 'Cell Division Worksheet', type: 'homework', due_date: format(addDays(now, 1), 'yyyy-MM-dd'), estimated_hours: 1, difficulty: 5, confidence: 6, priority: 'medium', status: 'completed', completed_at: format(now, "yyyy-MM-dd'T'HH:mm:ss") },
  ];

  for (const a of assignments) {
    db.prepare(`INSERT OR REPLACE INTO assignments (id, user_id, subject_id, title, type, due_date, estimated_hours, difficulty, confidence, priority, status, completed_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(a.id, userId, a.subject_id, a.title, a.type, a.due_date, a.estimated_hours, a.difficulty, a.confidence, a.priority, a.status || 'pending', a.completed_at || null);
  }

  // Study sessions (last 2 weeks + upcoming)
  const sessionData = [];
  for (let i = 13; i >= 1; i--) {
    const d = subDays(now, i);
    if (d.getDay() !== 0) { // Skip some Sundays
      sessionData.push({
        id: uuidv4(), user_id: userId,
        assignment_id: assignments[Math.floor(Math.random() * 4)].id,
        subject_id: subjects[Math.floor(Math.random() * 5)].id,
        title: `Study Session`,
        scheduled_start: format(d, "yyyy-MM-dd") + 'T16:00:00',
        scheduled_end: format(d, "yyyy-MM-dd") + 'T17:30:00',
        duration_minutes: 90,
        status: Math.random() > 0.15 ? 'completed' : 'missed',
        xp_awarded: 50,
      });
    }
  }

  // Upcoming sessions
  for (let i = 0; i < 7; i++) {
    const d = addDays(now, i);
    if (d.getDay() !== 0) {
      sessionData.push({
        id: uuidv4(), user_id: userId,
        assignment_id: assignments[i % assignments.length].id,
        subject_id: subjects[i % subjects.length].id,
        title: `Study: ${subjects[i % subjects.length].name}`,
        scheduled_start: format(d, "yyyy-MM-dd") + 'T16:00:00',
        scheduled_end: format(d, "yyyy-MM-dd") + 'T17:30:00',
        duration_minutes: 90,
        status: 'scheduled',
        xp_awarded: 0,
      });
    }
  }

  for (const s of sessionData) {
    db.prepare(`INSERT OR REPLACE INTO study_sessions (id, user_id, assignment_id, subject_id, title, scheduled_start, scheduled_end, duration_minutes, status, xp_awarded)
      VALUES (?,?,?,?,?,?,?,?,?,?)`)
      .run(s.id, s.user_id, s.assignment_id, s.subject_id, s.title, s.scheduled_start, s.scheduled_end, s.duration_minutes, s.status, s.xp_awarded);
  }

  // Review items
  const reviews = [
    { id: uuidv4(), subject_id: subjects[0].id, topic: 'Quadratic Formula', next_review_date: format(addDays(now, 0), 'yyyy-MM-dd'), interval_days: 1 },
    { id: uuidv4(), subject_id: subjects[1].id, topic: 'Mitosis vs Meiosis', next_review_date: format(addDays(now, 1), 'yyyy-MM-dd'), interval_days: 3 },
    { id: uuidv4(), subject_id: subjects[2].id, topic: 'Causes of WWI', next_review_date: format(addDays(now, 2), 'yyyy-MM-dd'), interval_days: 7 },
    { id: uuidv4(), subject_id: subjects[4].id, topic: 'Acid-Base Reactions', next_review_date: format(addDays(now, 0), 'yyyy-MM-dd'), interval_days: 1 },
  ];

  for (const r of reviews) {
    db.prepare(`INSERT OR REPLACE INTO review_items (id, user_id, assignment_id, subject_id, topic, next_review_date, interval_days)
      VALUES (?,?,?,?,?,?,?)`)
      .run(r.id, userId, null, r.subject_id, r.topic, r.next_review_date, r.interval_days);
  }

  // Achievements
  const badges = ['first_session', 'streak_3', 'streak_7', 'night_owl', 'early_bird'];
  for (const badge of badges) {
    db.prepare(`INSERT OR IGNORE INTO achievements (id, user_id, badge_id) VALUES (?,?,?)`)
      .run(uuidv4(), userId, badge);
  }

  // XP events
  const xpEvents = [
    { type: 'session_complete', amount: 50, desc: 'Completed study session' },
    { type: 'streak_bonus', amount: 500, desc: '7-day streak bonus!' },
    { type: 'session_complete', amount: 50, desc: 'Completed study session' },
    { type: 'week_complete', amount: 250, desc: 'Completed weekly goal' },
    { type: 'session_complete', amount: 50, desc: 'Completed study session' },
  ];
  for (const e of xpEvents) {
    db.prepare(`INSERT INTO xp_events (id, user_id, event_type, xp_amount, description) VALUES (?,?,?,?,?)`)
      .run(uuidv4(), userId, e.type, e.amount, e.desc);
  }

  console.log('✅ Seed complete. Demo login: demo@studyflow.ai / demo1234');
  process.exit(0);
}

seed().catch(e => { console.error(e); process.exit(1); });
