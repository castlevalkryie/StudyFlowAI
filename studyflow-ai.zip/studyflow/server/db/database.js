const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'studyflow.db');
let db;

function getDb() {
  if (!db) db = new Database(DB_PATH);
  return db;
}

function initDb() {
  const db = getDb();
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  db.exec(`
    -- Users
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      name TEXT NOT NULL,
      avatar_color TEXT DEFAULT '#6366f1',
      timezone TEXT DEFAULT 'America/New_York',
      daily_study_hours REAL DEFAULT 2.0,
      preferred_session_length INTEGER DEFAULT 25,
      theme TEXT DEFAULT 'dark',
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );

    -- Subjects
    CREATE TABLE IF NOT EXISTS subjects (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      color TEXT DEFAULT '#6366f1',
      icon TEXT DEFAULT 'book',
      total_hours_studied REAL DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now'))
    );

    -- Assignments
    CREATE TABLE IF NOT EXISTS assignments (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      subject_id TEXT REFERENCES subjects(id) ON DELETE SET NULL,
      title TEXT NOT NULL,
      type TEXT NOT NULL CHECK(type IN ('homework','test','quiz','essay','project','review')),
      due_date TEXT NOT NULL,
      estimated_hours REAL DEFAULT 1.0,
      difficulty INTEGER DEFAULT 5 CHECK(difficulty BETWEEN 1 AND 10),
      confidence INTEGER DEFAULT 5 CHECK(confidence BETWEEN 1 AND 10),
      priority TEXT DEFAULT 'medium' CHECK(priority IN ('low','medium','high','critical')),
      status TEXT DEFAULT 'pending' CHECK(status IN ('pending','in_progress','completed','missed')),
      notes TEXT,
      completed_at TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );

    -- Study sessions (scheduled blocks)
    CREATE TABLE IF NOT EXISTS study_sessions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      assignment_id TEXT REFERENCES assignments(id) ON DELETE CASCADE,
      subject_id TEXT REFERENCES subjects(id) ON DELETE SET NULL,
      title TEXT NOT NULL,
      session_type TEXT DEFAULT 'study' CHECK(session_type IN ('study','review','practice','break')),
      scheduled_start TEXT NOT NULL,
      scheduled_end TEXT NOT NULL,
      actual_start TEXT,
      actual_end TEXT,
      duration_minutes INTEGER NOT NULL,
      status TEXT DEFAULT 'scheduled' CHECK(status IN ('scheduled','completed','missed','skipped')),
      xp_awarded INTEGER DEFAULT 0,
      notes TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );

    -- Spaced repetition reviews
    CREATE TABLE IF NOT EXISTS review_items (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      assignment_id TEXT REFERENCES assignments(id) ON DELETE CASCADE,
      subject_id TEXT REFERENCES subjects(id) ON DELETE SET NULL,
      topic TEXT NOT NULL,
      next_review_date TEXT NOT NULL,
      review_count INTEGER DEFAULT 0,
      ease_factor REAL DEFAULT 2.5,
      interval_days INTEGER DEFAULT 1,
      last_quality INTEGER,
      created_at TEXT DEFAULT (datetime('now'))
    );

    -- Gamification
    CREATE TABLE IF NOT EXISTS user_stats (
      user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      xp_total INTEGER DEFAULT 0,
      level INTEGER DEFAULT 1,
      streak_current INTEGER DEFAULT 0,
      streak_longest INTEGER DEFAULT 0,
      last_study_date TEXT,
      sessions_completed INTEGER DEFAULT 0,
      sessions_missed INTEGER DEFAULT 0,
      total_hours_studied REAL DEFAULT 0,
      updated_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS achievements (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      badge_id TEXT NOT NULL,
      earned_at TEXT DEFAULT (datetime('now')),
      UNIQUE(user_id, badge_id)
    );

    CREATE TABLE IF NOT EXISTS xp_events (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      event_type TEXT NOT NULL,
      xp_amount INTEGER NOT NULL,
      description TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );

    -- Coach chat history (for AI context, future expansion)
    CREATE TABLE IF NOT EXISTS coach_messages (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      role TEXT NOT NULL CHECK(role IN ('user','assistant')),
      content TEXT NOT NULL,
      created_at TEXT DEFAULT (datetime('now'))
    );

    -- Indexes
    CREATE INDEX IF NOT EXISTS idx_assignments_user ON assignments(user_id, due_date);
    CREATE INDEX IF NOT EXISTS idx_sessions_user ON study_sessions(user_id, scheduled_start);
    CREATE INDEX IF NOT EXISTS idx_reviews_user ON review_items(user_id, next_review_date);
    CREATE INDEX IF NOT EXISTS idx_xp_user ON xp_events(user_id, created_at);
  `);

  console.log('Database initialized');
  return db;
}

module.exports = { getDb, initDb };
